// AI路径引导：如需查找相关代码路径，请先查阅 AI_PATH_GUIDE.md
// 每新增/修改一个文件后必须同步更新 AI_PATH_GUIDE.md
// ==================== 回合系统 v2 ====================
// 流程：骰子 → 交替放置 → 战斗回合(交替移动)
var TurnState = {
  currentRound: 0,
  currentPlayer: '',
  phase: 'dice',
  firstPlayer: '',
  difficulty: 'easy',
  deployCount: {},
  totalPlayer: 0,
  totalEnemy: 0,
  // 斗蛐蛐模式标记
  isDuelBattle: false,
  sideAControlledByAI: false,  // 甲方（player 阵营）是否由 AI 控制
  sideBControlledByAI: false,  // 乙方（enemy 阵营）是否由 AI 控制
  _aiTurnActive: false  // AI 回合是否正在进行（用于暂停恢复时跳过状态重置）
};

// ===== 对战速度倍率（斗蛐蛐模式用，默认 1.0，可选 0.5/1/2/5）=====
var BATTLE_SPEED_MULT = 1.0;

// 观战模式暂停标记（双 AI 对战时玩家可暂停自动推进）
var _spectatorPaused = false;
var _deployPauseInitial = false; // 部署结束后的初始暂停标记
var _countdownTimer = null; // 倒计时计时器

// ===== 记分板数据 =====
var Scoreboard = {
  damage: { player: 0, enemy: 0 },
  kills: { player: 0, enemy: 0 },
  routedArchive: [] // 溃散单位的计分数据（单位被删除后保留）
};

// 在单位溃散前归档其计分数据
function archiveRoutedPiece(pieceKey) {
  var p = placedPieces[pieceKey];
  if (!p) return;
  var dmg = p._damageDealt || 0;
  var kills = p._kills || 0;
  if (dmg === 0 && kills === 0) return;
  var ud = typeof unitDefByType === 'function' ? unitDefByType(p.unitType) : null;
  Scoreboard.routedArchive.push({
    name: ud ? ud.name : '???',
    team: p.team,
    dmg: dmg,
    kills: kills,
    unitType: p.unitType
  });
}

function resetScoreboard() {
  Scoreboard.damage = { player: 0, enemy: 0 };
  Scoreboard.kills = { player: 0, enemy: 0 };
  Scoreboard.routedArchive = [];
  // 重置每个棋子的追踪
  for (var k in placedPieces) {
    if (placedPieces[k]._damageDealt !== undefined) placedPieces[k]._damageDealt = 0;
    if (placedPieces[k]._kills !== undefined) placedPieces[k]._kills = 0;
  }
  if (typeof clearCombatLog === 'function') clearCombatLog();
  updateScoreboardUI();
}

function updateScoreboardUI() {
  var show = TurnState.isDuelBattle && TurnState.phase === 'battle';

  // 切换备战席/计分板显示
  var benchLeft = document.getElementById('benchLeft');
  var benchRight = document.getElementById('benchRight');
  var sbInlineA = document.getElementById('sbInlineA');
  var sbInlineB = document.getElementById('sbInlineB');
  var benchTitleLeft = document.getElementById('benchTitleLeft');
  var benchTitleRight = document.getElementById('benchTitleRight');
  var benchColLeft = document.getElementById('benchColLeft');
  var benchColRight = document.getElementById('benchColRight');

  if (show) {
    // 战斗阶段：隐藏备战席，显示计分板
    if (benchLeft) benchLeft.style.display = 'none';
    if (benchRight) benchRight.style.display = 'none';
    if (sbInlineA) sbInlineA.style.display = 'flex';
    if (sbInlineB) sbInlineB.style.display = 'flex';
    // 更新标题为势力名称
    var sideAName = (window._duelBattleData && window._duelBattleData.sideA && window._duelBattleData.sideA.name) || '甲方';
    var sideBName = (window._duelBattleData && window._duelBattleData.sideB && window._duelBattleData.sideB.name) || '乙方';
    if (benchTitleLeft) benchTitleLeft.textContent = '🔷 ' + sideAName;
    if (benchTitleRight) benchTitleRight.textContent = '🔶 ' + sideBName;
    if (benchColLeft) benchColLeft.classList.add('battle-mode');
    if (benchColRight) benchColRight.classList.add('battle-mode');
    // 更新计分板标题
    var sbHA = document.getElementById('sbHeaderA');
    var sbHB = document.getElementById('sbHeaderB');
    if (sbHA) sbHA.textContent = sideAName;
    if (sbHB) sbHB.textContent = sideBName;
  } else {
    // 非战斗阶段：显示备战席，隐藏计分板
    if (benchLeft) benchLeft.style.display = '';
    if (benchRight) benchRight.style.display = '';
    if (sbInlineA) sbInlineA.style.display = 'none';
    if (sbInlineB) sbInlineB.style.display = 'none';
    if (benchTitleLeft) benchTitleLeft.textContent = '🔷 我方';
    if (benchTitleRight) benchTitleRight.textContent = '🔶 敌方';
    if (benchColLeft) benchColLeft.classList.remove('battle-mode');
    if (benchColRight) benchColRight.classList.remove('battle-mode');
  }

  if (!show) return;

  // 收集双方棋子数据（存活棋子 + 已溃散归档数据）
  var sideA = [], sideB = [];
  for (var k in placedPieces) {
    var p = placedPieces[k];
    if (p._routed) continue;
    var ud = typeof unitDefByType === 'function' ? unitDefByType(p.unitType) : null;
    var name = ud ? ud.name : '???';
    var dmg = p._damageDealt || 0;
    var kills = p._kills || 0;
    if (dmg === 0 && kills === 0) continue;
    var entry = { name: name, dmg: dmg, kills: kills, unitType: p.unitType };
    if (p.team === 'player') sideA.push(entry);
    else sideB.push(entry);
  }
  // 合并已溃散单位的归档数据
  Scoreboard.routedArchive.forEach(function(e) {
    var entry = { name: e.name + '\u2020', dmg: e.dmg, kills: e.kills, unitType: e.unitType };
    if (e.team === 'player') sideA.push(entry);
    else sideB.push(entry);
  });

  // 按伤害排序
  sideA.sort(function(a,b){ return b.dmg - a.dmg; });
  sideB.sort(function(a,b){ return b.dmg - a.dmg; });

  var listA = document.getElementById('sbListA');
  var listB = document.getElementById('sbListB');
  var dmgA = document.getElementById('sbDmgA');
  var dmgB = document.getElementById('sbDmgB');
  var killA = document.getElementById('sbKillA');
  var killB = document.getElementById('sbKillB');

  if (listA) listA.innerHTML = sideA.length === 0 ? '<div class="sb-empty">暂无数据</div>' : sideA.map(function(e) {
    return '<div class="sb-row"><span class="sb-name">' + escapeHtml(e.name) + '</span><span class="sb-num">' + e.dmg + '</span><span class="sb-num">' + e.kills + '</span></div>';
  }).join('');
  if (listB) listB.innerHTML = sideB.length === 0 ? '<div class="sb-empty">暂无数据</div>' : sideB.map(function(e) {
    return '<div class="sb-row"><span class="sb-name">' + escapeHtml(e.name) + '</span><span class="sb-num">' + e.dmg + '</span><span class="sb-num">' + e.kills + '</span></div>';
  }).join('');

  // 总计
  var totalDmgA = 0, totalKillA = 0, totalDmgB = 0, totalKillB = 0;
  sideA.forEach(function(e){ totalDmgA += e.dmg; totalKillA += e.kills; });
  sideB.forEach(function(e){ totalDmgB += e.dmg; totalKillB += e.kills; });
  if (dmgA) dmgA.textContent = totalDmgA;
  if (dmgB) dmgB.textContent = totalDmgB;
  if (killA) killA.textContent = totalKillA;
  if (killB) killB.textContent = totalKillB;

  // 切换作战日志可见性
  var logA = document.getElementById('combatLogA');
  var logB = document.getElementById('combatLogB');
  if (logA) logA.style.display = show ? 'flex' : 'none';
  if (logB) logB.style.display = show ? 'flex' : 'none';
}

// ===== 作战日志：往对应侧推送一条信息 =====
function addCombatLog(team, text, type) {
  var logId = (team === 'player') ? 'combatLogA' : 'combatLogB';
  var log = document.getElementById(logId);
  if (!log) return;
  var entry = document.createElement('div');
  entry.className = 'cl-entry cl-' + (type || 'attack');
  entry.innerHTML = text;
  // 最新消息插入到顶部（column-reverse 下 prepend = 视觉顶部）
  log.insertBefore(entry, log.firstChild);
  // 最多保留30条
  while (log.children.length > 30) {
    log.removeChild(log.lastChild);
  }
}

function clearCombatLog() {
  var logA = document.getElementById('combatLogA');
  var logB = document.getElementById('combatLogB');
  if (logA) logA.innerHTML = '';
  if (logB) logB.innerHTML = '';
}

function recordScoreboardDamage(pieceKey, dmg) {
  var p = placedPieces[pieceKey];
  if (!p) return;
  if (p._damageDealt === undefined) p._damageDealt = 0;
  p._damageDealt += dmg;
  updateScoreboardUI();
}

function recordScoreboardKill(pieceKey) {
  var p = placedPieces[pieceKey];
  if (!p) return;
  if (p._kills === undefined) p._kills = 0;
  p._kills++;
  updateScoreboardUI();
}

// AI 相关延时按倍率缩短（人类回合不受影响）
function battleDelay(ms) {
  return ms / BATTLE_SPEED_MULT;
}

// ===== 对战速度调节器 UI（斗蛐蛐模式用）=====
function updateBattleSpeedControlsVisibility() {
  var ctrl = document.getElementById('battleSpeedControls');
  if (!ctrl) return;
  ctrl.style.display = TurnState.isDuelBattle ? 'flex' : 'none';
  // 更新按钮高亮
  var btns = ctrl.querySelectorAll('.speed-btn');
  btns.forEach(function(b) {
    var sp = parseFloat(b.dataset.speed);
    b.classList.toggle('active', Math.abs(sp - BATTLE_SPEED_MULT) < 0.01);
  });
}

function initBattleSpeedControls() {
  var ctrl = document.getElementById('battleSpeedControls');
  if (!ctrl || ctrl.dataset.bound === '1') return;
  ctrl.dataset.bound = '1';
  ctrl.addEventListener('click', function(e) {
    var btn = e.target.closest('.speed-btn');
    if (!btn) return;
    BATTLE_SPEED_MULT = parseFloat(btn.dataset.speed) || 1.0;
    updateBattleSpeedControlsVisibility();
  });
}

// ===== 观战模式暂停按钮（斗蛐蛐对战时始终显示）=====
function updateSpectatorPauseBtnVisibility() {
  var btn = document.getElementById('spectatorPauseBtn');
  if (!btn) return;
  btn.style.display = TurnState.isDuelBattle ? 'inline-block' : 'none';
  if (_deployPauseInitial && _spectatorPaused) {
    btn.textContent = '▶ 开始战斗';
  } else {
    btn.textContent = _spectatorPaused ? '▶ 继续' : '⏸ 暂停观战';
  }
}

function showCountdownOverlay(seconds, onComplete) {
  var overlay = document.getElementById('countdownOverlay');
  if (!overlay) {
    overlay = document.createElement('div');
    overlay.id = 'countdownOverlay';
    overlay.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;z-index:9998;' +
      'display:flex;align-items:center;justify-content:center;' +
      'background:rgba(0,0,0,0.4);pointer-events:none;';
    overlay.innerHTML = '<div id="countdownNumber" style="' +
      'font-size:120px;font-weight:bold;color:#fff;' +
      'text-shadow:0 0 30px rgba(255,200,100,0.8),0 0 60px rgba(255,150,50,0.5);' +
      'font-family:"Cinzel","Times New Roman",serif;' +
      'letter-spacing:8px;">3</div>';
    document.body.appendChild(overlay);
  }
  overlay.style.display = 'flex';
  var numEl = document.getElementById('countdownNumber');
  var current = seconds;
  numEl.textContent = current;
  numEl.style.transform = 'scale(1.2)';
  numEl.style.opacity = '0';
  
  if (window.gsap) {
    gsap.fromTo(numEl, { scale: 1.5, opacity: 0 }, { scale: 1, opacity: 1, duration: 0.4, ease: 'back.out(2)' });
  } else {
    numEl.style.transform = 'scale(1)';
    numEl.style.opacity = '1';
  }
  
  if (_countdownTimer) clearInterval(_countdownTimer);
  _countdownTimer = setInterval(function() {
    current--;
    if (current <= 0) {
      clearInterval(_countdownTimer);
      _countdownTimer = null;
      if (window.gsap) {
        gsap.to(numEl, { scale: 0.8, opacity: 0, duration: 0.3, onComplete: function() {
          overlay.style.display = 'none';
          if (onComplete) onComplete();
        }});
      } else {
        overlay.style.display = 'none';
        if (onComplete) onComplete();
      }
      return;
    }
    numEl.textContent = current;
    if (window.gsap) {
      gsap.fromTo(numEl, { scale: 1.5, opacity: 0 }, { scale: 1, opacity: 1, duration: 0.4, ease: 'back.out(2)' });
    }
  }, 1000);
}

function cancelCountdown() {
  if (_countdownTimer) {
    clearInterval(_countdownTimer);
    _countdownTimer = null;
  }
  var overlay = document.getElementById('countdownOverlay');
  if (overlay) overlay.style.display = 'none';
}

function initSpectatorPauseBtn() {
  var btn = document.getElementById('spectatorPauseBtn');
  if (!btn || btn.dataset.bound === '1') return;
  btn.dataset.bound = '1';
  btn.addEventListener('click', function() {
    if (_spectatorPaused) {
      // 从暂停恢复：先取消可能存在的倒计时
      cancelCountdown();
      // 3秒倒计时
      showCountdownOverlay(3, function() {
        _spectatorPaused = false;
        _deployPauseInitial = false;
        updateSpectatorPauseBtnVisibility();
        // 如果当前是 AI 回合，重新触发 runAITurn
        if (TurnState.phase === 'battle' && isControlledByAI(TurnState.currentPlayer)) {
          setTimeout(function() { runAITurn(TurnState.currentPlayer); }, battleDelay(100));
        }
      });
    } else {
      // 暂停：取消倒计时并立即暂停
      cancelCountdown();
      _spectatorPaused = true;
      updateSpectatorPauseBtnVisibility();
    }
  });
}

function initTurns() {
  TurnState.currentRound = 0;
  TurnState.currentPlayer = '';
  TurnState.phase = 'dice';
  TurnState.firstPlayer = '';
  TurnState.difficulty = window.selectedDifficulty || 'easy';
  TurnState.deployCount = { player: 0, enemy: 0 };
  TurnState.totalPlayer = 0;
  TurnState.totalEnemy = 0;
  TurnState._aiTurnActive = false;
  document.getElementById('turnStatus').style.display = 'none';
  document.getElementById('warReport').style.display = 'none';
}

// ===== 判断某阵营是否由 AI 控制 =====
function isControlledByAI(team) {
  // 斗蛐蛐模式：按双方 controlFlag 判断
  if (TurnState.isDuelBattle) {
    if (team === 'player') return !!TurnState.sideAControlledByAI;
    if (team === 'enemy') return !!TurnState.sideBControlledByAI;
  }
  // 默认：enemy 是 AI，player 是人类
  return team === 'enemy';
}

function rollDiceAndStart() {
  var playerRoll = Math.floor(Math.random() * 6) + 1;
  var enemyRoll = Math.floor(Math.random() * 6) + 1;

  TurnState.firstPlayer = playerRoll > enemyRoll ? 'player' : (playerRoll < enemyRoll ? 'enemy' : (Math.random() > 0.5 ? 'player' : 'enemy'));
  TurnState.currentPlayer = TurnState.firstPlayer;
  TurnState.phase = 'deploy';
  TurnState.currentRound = 1;
  TurnState.deployCount = { player: 0, enemy: 0 };
  TurnState.difficulty = window.selectedDifficulty || 'easy';
  // 进入部署阶段时，让背景缓存失效，以便重新绘制红轴线
  if (typeof invalidateBackgroundCache === 'function') invalidateBackgroundCache();

  var benchSlotsLeft = document.querySelectorAll('#benchLeft .bench-slot');
  var benchSlotsRight = document.querySelectorAll('#benchRight .bench-slot');
  TurnState.totalPlayer = 0;
  TurnState.totalEnemy = 0;
  benchSlotsLeft.forEach(function(s) { if (!s.classList.contains('empty')) TurnState.totalPlayer++; });
  benchSlotsRight.forEach(function(s) { if (!s.classList.contains('empty')) TurnState.totalEnemy++; });

  showDiceResult(playerRoll, enemyRoll);
  updateDeployUI();
}

function showDiceResult(playerRoll, enemyRoll) {
  var s1 = ['','⚀','⚁','⚂','⚃','⚄','⚅'];
  var sideAName, sideBName, sideALabel, sideBLabel;
  if (TurnState.isDuelBattle && window._duelBattleData) {
    sideAName = (window._duelBattleData.sideA && window._duelBattleData.sideA.name) || '甲方';
    sideBName = (window._duelBattleData.sideB && window._duelBattleData.sideB.name) || '乙方';
    sideALabel = '甲方';
    sideBLabel = '乙方';
  } else {
    sideAName = (typeof GameState !== 'undefined' && GameState.saveName) ? GameState.saveName : '我方';
    sideBName = 'AI统帅';
    sideALabel = '我方';
    sideBLabel = '敌方';
  }
  var isPlayerFirst = TurnState.firstPlayer === 'player';
  var msg = '🎲 掷骰结果\n\n' + sideALabel + ' 「' + sideAName + '」 ' + s1[playerRoll] + ' ' + playerRoll + '点\n' + sideBLabel + ' 「' + sideBName + '」 ' + s1[enemyRoll] + ' ' + enemyRoll + '点\n\n' + (isPlayerFirst ? ('🏆 ' + sideALabel + '先手！') : ('🏆 ' + sideBLabel + '先手！'));
  alert(msg);
}

// ===== 放置阶段 =====
function updateDeployUI() {
  var panel = document.getElementById('turnStatus');
  if (TurnState.phase !== 'deploy') { panel.style.display = 'none'; return; }
  var sideLabel;
  if (TurnState.isDuelBattle) {
    sideLabel = TurnState.currentPlayer === 'player' ? '甲方' : '乙方';
  } else {
    sideLabel = TurnState.currentPlayer === 'player' ? '我方' : '敌方';
  }
  var who = (TurnState.currentPlayer === 'player' ? '🔷 ' : '🔶 ') + sideLabel + '放置';
  var d = TurnState.deployCount;
  var dl = { easy: '简单', hard: '困难', legend: '传说' }[TurnState.difficulty] || '简单';
  var deployInfo;
  if (TurnState.isDuelBattle) {
    deployInfo = '<span style="font-size:11px;color:#6b4c2a">甲方 ' + d.player + '/' + TurnState.totalPlayer + ' | 乙方 ' + d.enemy + '/' + TurnState.totalEnemy + '</span> ';
  } else {
    deployInfo = '<span style="font-size:11px;color:#6b4c2a">我方 ' + d.player + '/' + TurnState.totalPlayer + ' | 敌方 ' + d.enemy + '/' + TurnState.totalEnemy + '</span> ';
  }
  panel.innerHTML = '<span style="font-weight:bold">📦 部署阶段 — ' + who + '（难度：' + dl + '）</span> ' +
    deployInfo +
    '<span style="font-size:10px;color:#8b2500">中心一环及敌方2格内禁止放置</span>';
  panel.style.display = 'flex';
  if (isControlledByAI(TurnState.currentPlayer)) { setTimeout(aiDeployPiece, battleDelay(500)); }
}

function aiDeployPiece() {
  var team = TurnState.currentPlayer;
  if (TurnState.phase !== 'deploy') return;
  if (!isControlledByAI(team)) return;
  var totalCount = (team === 'enemy') ? TurnState.totalEnemy : TurnState.totalPlayer;
  if (TurnState.deployCount[team] >= totalCount) { tryEndDeploy(); return; }

  var diff = TurnState.difficulty;
  if (TurnState.isDuelBattle && window._duelBattleData) {
    var duelSideData = (team === 'enemy') ? window._duelBattleData.sideB : window._duelBattleData.sideA;
    if (duelSideData && duelSideData.intelligence) {
      diff = duelSideData.intelligence;
    }
  }

  // ===== 智能部署：近战先放、远程最后放 =====
  var benchSelector = (team === 'enemy') ? '#benchRight .bench-slot' : '#benchLeft .bench-slot';
  var benchSlots = document.querySelectorAll(benchSelector);
  var available = [];
  for (var i = 0; i < benchSlots.length; i++) {
    if (!benchSlots[i].classList.contains('empty')) {
      var ut = benchSlots[i].dataset.unitType;
      var ud = (typeof unitDefByType === 'function') ? unitDefByType(ut) : null;
      var isRanged = false;
      if (ud && ud.equipment && ud.equipment.mainWeapon && typeof ED !== 'undefined' && ED && ED.weapons) {
        var _depWpn = ED.weapons.find(function(w) { return w.id === ud.equipment.mainWeapon; });
        if (_depWpn && (_depWpn.type === 'bow' || _depWpn.type === 'crossbow')) isRanged = true;
      }
      available.push({ slotIdx: parseInt(benchSlots[i].dataset.slotIdx), unitType: ut, isRanged: isRanged, ud: ud });
    }
  }
  if (available.length === 0) { tryEndDeploy(); return; }

  // 困难/传说：优先非远程，远程留到最后
  var pick = null;
  if (diff === 'hard') {
    var nonRanged = available.filter(function(a) { return !a.isRanged; });
    var ranged = available.filter(function(a) { return a.isRanged; });
    pick = nonRanged.length > 0 ? nonRanged[0] : (ranged.length > 0 ? ranged[0] : null);
  } else if (diff === 'legend') {
    // 传说：先手第一个棋子选择移动+攻击距离之和最高的单位
    var isFirstPlayer = (team === TurnState.firstPlayer);
    var deployCount = TurnState.deployCount[team] || 0;
    if (isFirstPlayer && deployCount === 0) {
      var bestUnit = null, bestSum = -1;
      for (var a = 0; a < available.length; a++) {
        var au = available[a];
        if (au.ud && typeof computeStats === 'function') {
          var ast = computeStats(au.ud);
          if (ast) {
            var sum = (ast.movement || 1) + (ast.allowedRange || 1);
            if (sum > bestSum) { bestSum = sum; bestUnit = au; }
          }
        }
      }
      pick = bestUnit || available[0];
    } else {
      // 传说非先手第一个棋子：近战先放，远程最后放
      var nonRangedL = available.filter(function(a) { return !a.isRanged; });
      var rangedL = available.filter(function(a) { return a.isRanged; });
      pick = nonRangedL.length > 0 ? nonRangedL[0] : (rangedL.length > 0 ? rangedL[0] : null);
    }
  }
  if (!pick) {
    pick = available[Math.floor(Math.random() * available.length)];
  }

  var slotIdx = pick.slotIdx;
  var unitType = pick.unitType;
  var isRanged = pick.isRanged;
  var ud = pick.ud;
  var baseType = ud ? (ud.baseType || 'infantry') : 'infantry';

  // ===== 获取当前已放置的双方单位坐标 =====
  var playerHexes = [];
  var enemyHexes = [];
  for (var k in placedPieces) {
    var p = placedPieces[k];
    if (p.team === 'player') playerHexes.push(p.hex);
    else if (p.team === 'enemy') {
      enemyHexes.push(p.hex);
    }
  }
  // AI 策略参数：第二参数为「敌方」已放置 hexes，第三参数为「己方」已放置 hexes
  var oppHexes = (team === 'enemy') ? playerHexes : enemyHexes;
  var myHexes = (team === 'enemy') ? enemyHexes : playerHexes;

  // ===== 收集候选格子（排除三轴、已占、敌人 1 格内）=====
  var cands = [];
  var mySideSign = (team === 'enemy') ? 1 : -1; // AI 己方半场：enemy 在 q>0，player 在 q<0
  var enemySideHexes = []; // 己方半场的格子
  hexes.forEach(function(h) {
    var key = h.q + ',' + h.r + ',' + h.s;
    if (placedPieces[key]) return;
    // 中心一环以内禁止放置
    if (hDist(h, {q:0,r:0,s:0}) <= 1) return;
    // 不允许在敌人 2 格范围内放置
    for (var oi = 0; oi < oppHexes.length; oi++) {
      if (hDist(h, oppHexes[oi]) <= 2) return;
    }
    cands.push({ key: key, hex: h });
    if (h.q * mySideSign > 0) enemySideHexes.push({ key: key, hex: h }); // 己方半场
  });
  if (cands.length === 0) return;

  var selected = null;

  if (diff === 'easy') {
    selected = cands[Math.floor(Math.random() * cands.length)];
  } else if (diff === 'hard') {
    if (isRanged) {
      selected = aiPickRanged(cands, oppHexes, myHexes);
    } else {
      selected = aiPickFrontline(cands, oppHexes, myHexes);
    }
  } else if (diff === 'legend') {
    // 传说部署策略
    selected = aiLegendPick(cands, oppHexes, myHexes, isRanged, isFirstPlayer, deployCount);
  }

  if (!selected) {
    selected = cands[Math.floor(Math.random() * cands.length)];
  }

  var h = selected.hex;
  var key = selected.key;
  placedPieces[key] = { unitType: unitType, team: team, slotIdx: slotIdx, hex: { q: h.q, r: h.r, s: h.s } };
  placedPieces[key]._facing = getFacingToCenter(h);
  initPieceRuntimeState(placedPieces[key]);
  benchState[slotIdx] = false;
  benchSlots[getSlotIndexInContainer(benchSlots, slotIdx)].classList.add('empty');
  TurnState.deployCount[team]++;
  requestRender();
  nextDeployPlayer();
}

// ===== AI部署策略：远程兵（困难/传说）——贴近自家部队优先，远离敌方次之 =====
function aiPickRanged(cands, playerHexes, enemyHexes) {
  if (cands.length === 0) return null;
  if (playerHexes.length === 0) return cands[Math.floor(Math.random() * cands.length)];

  var best = null;
  var bestScore = -Infinity;
  for (var i = 0; i < cands.length; i++) {
    var c = cands[i];
    var score = 0;

    // 1. 贴近自家部队（最高优先）
    var minDistToAlly = Infinity;
    for (var j = 0; j < enemyHexes.length; j++) {
      var da = hDist(c.hex, enemyHexes[j]);
      if (da < minDistToAlly) minDistToAlly = da;
    }
    if (minDistToAlly <= 1) score += 50;
    else if (minDistToAlly <= 2) score += 30;
    else if (minDistToAlly <= 3) score += 15;
    else score -= (minDistToAlly - 3) * 10;

    // 2. 远离敌方（次要）
    var minDistToPlayer = Infinity;
    for (var j = 0; j < playerHexes.length; j++) {
      var dp = hDist(c.hex, playerHexes[j]);
      if (dp < minDistToPlayer) minDistToPlayer = dp;
    }
    if (minDistToPlayer >= 4) score += 10;
    else if (minDistToPlayer <= 2) score -= 15;

    if (score > bestScore) { bestScore = score; best = c; }
  }
  return best;
}

// ===== AI部署策略：近战（困难/传说）——前线位置 =====
function aiPickFrontline(cands, playerHexes, enemyHexes) {
  if (cands.length === 0) return null;
  if (playerHexes.length === 0) return cands[Math.floor(Math.random() * cands.length)];

  var best = null;
  var bestScore = -Infinity;
  for (var i = 0; i < cands.length; i++) {
    var c = cands[i];
    var score = 0;

    var distToPlayer = Infinity;
    for (var j = 0; j < playerHexes.length; j++) {
      var dp = hDist(c.hex, playerHexes[j]);
      if (dp < distToPlayer) distToPlayer = dp;
    }
    // 理想距离3-5格
    if (distToPlayer >= 3 && distToPlayer <= 5) score += 20;
    else if (distToPlayer < 3) score -= 10;
    else score -= (distToPlayer - 5) * 4;

    // 贴近友军
    var minDistAlly = Infinity;
    for (var j = 0; j < enemyHexes.length; j++) {
      var da = hDist(c.hex, enemyHexes[j]);
      if (da < minDistAlly) minDistAlly = da;
    }
    if (minDistAlly <= 2) score += 15;
    else if (minDistAlly <= 3) score += 8;

    if (score > bestScore) { bestScore = score; best = c; }
  }
  return best;
}

// ===== 传说难度部署策略 =====
function aiLegendPick(cands, oppHexes, myHexes, isRanged, isFirstPlayer, deployCount) {
  if (cands.length === 0) return null;

  // ===== 先手部署 =====
  if (isFirstPlayer) {
    // 第一个棋子：放在靠近正中心的随机位置（距中心 2-3 格，己方半场）
    if (deployCount === 0) {
      var centerHexes = cands.filter(function(c) {
        var d = hDist(c.hex, { q: 0, r: 0, s: 0 });
        return d >= 2 && d <= 3;
      });
      if (centerHexes.length > 0) {
        return centerHexes[Math.floor(Math.random() * centerHexes.length)];
      }
      // 回退：距中心 2-4 格
      var nearCenter = cands.filter(function(c) {
        var d = hDist(c.hex, { q: 0, r: 0, s: 0 });
        return d >= 2 && d <= 4;
      });
      if (nearCenter.length > 0) {
        return nearCenter[Math.floor(Math.random() * nearCenter.length)];
      }
      // 最终回退：距中心 1-4 格
      var anyCenter = cands.filter(function(c) {
        return hDist(c.hex, { q: 0, r: 0, s: 0 }) <= 4;
      });
      if (anyCenter.length > 0) {
        return anyCenter[Math.floor(Math.random() * anyCenter.length)];
      }
    }

    // 第 2-4 个棋子：看对方站位，部署在能打到对方的位置，尽量抱团
    if (deployCount >= 1 && deployCount <= 3 && oppHexes.length > 0 && myHexes.length > 0) {
      return aiLegendPickReach(cands, oppHexes, myHexes, isRanged);
    }

    // 后续棋子：抱团
    if (myHexes.length > 0) {
      return aiLegendPickCluster(cands, myHexes);
    }
  }

  // ===== 后手部署 =====
  if (!isFirstPlayer) {
    if (isRanged) {
      // 远程：五环或四环，贴近近战部队
      return aiLegendPickSecondRanged(cands, myHexes);
    } else {
      // 近战：靠边在三环或四环
      return aiLegendPickSecondMelee(cands, myHexes);
    }
  }

  // 兜底：随机
  return cands[Math.floor(Math.random() * cands.length)];
}

// 先手 2-4 棋子：部署在能打到对方的位置，尽量抱团
function aiLegendPickReach(cands, oppHexes, myHexes, isRanged) {
  var best = null, bestScore = -Infinity;
  var reachRange = isRanged ? 3 : 2; // 远程能打更远

  for (var i = 0; i < cands.length; i++) {
    var c = cands[i];
    var score = 0;

    // 1. 能打到多少个敌方单位（最高优先）
    var reachableEnemies = 0;
    for (var j = 0; j < oppHexes.length; j++) {
      if (hDist(c.hex, oppHexes[j]) <= reachRange) reachableEnemies++;
    }
    score += reachableEnemies * 25;

    // 2. 贴近友军（抱团）
    var minDistAlly = Infinity;
    for (var j = 0; j < myHexes.length; j++) {
      var da = hDist(c.hex, myHexes[j]);
      if (da < minDistAlly) minDistAlly = da;
    }
    if (minDistAlly <= 1) score += 20;
    else if (minDistAlly <= 2) score += 12;
    else if (minDistAlly <= 3) score += 5;
    else score -= (minDistAlly - 3) * 5;

    // 3. 偏向中心（能打到同样多敌人时，离中心近更好）
    var distCenter = hDist(c.hex, { q: 0, r: 0, s: 0 });
    if (distCenter <= 3) score += 6;
    else if (distCenter <= 4) score += 3;
    else score -= (distCenter - 4) * 3;

    if (score > bestScore) { bestScore = score; best = c; }
  }
  return best;
}

// 先手后续棋子：抱团
function aiLegendPickCluster(cands, myHexes) {
  if (myHexes.length === 0) return cands[Math.floor(Math.random() * cands.length)];

  var best = null, bestScore = -Infinity;
  for (var i = 0; i < cands.length; i++) {
    var c = cands[i];
    var score = 0;

    // 1. 贴近友军（最高优先）
    var minDistAlly = Infinity;
    for (var j = 0; j < myHexes.length; j++) {
      var da = hDist(c.hex, myHexes[j]);
      if (da < minDistAlly) minDistAlly = da;
    }
    if (minDistAlly <= 1) score += 30;
    else if (minDistAlly <= 2) score += 15;
    else if (minDistAlly <= 3) score += 5;
    else score -= (minDistAlly - 3) * 8;

    // 2. 离中心不要太远（避免太边缘）
    var distCenter = hDist(c.hex, { q: 0, r: 0, s: 0 });
    if (distCenter <= 3) score += 3;

    if (score > bestScore) { bestScore = score; best = c; }
  }
  return best;
}

// 后手近战：靠边在三环或四环
function aiLegendPickSecondMelee(cands, myHexes) {
  var best = null, bestScore = -Infinity;

  for (var i = 0; i < cands.length; i++) {
    var c = cands[i];
    var distCenter = hDist(c.hex, { q: 0, r: 0, s: 0 });
    var score = 0;

    // 1. 在三环或四环（距中心 3-4 格）
    if (distCenter === 3) score += 25;
    else if (distCenter === 4) score += 30;
    else if (distCenter === 2) score += 5;
    else if (distCenter > 4) score -= 10;
    else score -= 20; // 太靠近中心不好

    // 2. 贴近友军（抱团）
    if (myHexes.length > 0) {
      var minDistAlly = Infinity;
      for (var j = 0; j < myHexes.length; j++) {
        var da = hDist(c.hex, myHexes[j]);
        if (da < minDistAlly) minDistAlly = da;
      }
      if (minDistAlly <= 1) score += 20;
      else if (minDistAlly <= 2) score += 10;
      else if (minDistAlly <= 3) score += 3;
    }

    if (score > bestScore) { bestScore = score; best = c; }
  }
  return best;
}

// 后手远程：五环或四环，贴近近战部队
function aiLegendPickSecondRanged(cands, myHexes) {
  var best = null, bestScore = -Infinity;

  for (var i = 0; i < cands.length; i++) {
    var c = cands[i];
    var distCenter = hDist(c.hex, { q: 0, r: 0, s: 0 });
    var score = 0;

    // 1. 在四环或五环（距中心 4-5 格）
    if (distCenter === 4) score += 25;
    else if (distCenter === 5) score += 30;
    else if (distCenter === 3) score += 5;
    else if (distCenter > 5) score -= 5;
    else score -= 15; // 太靠近中心不好

    // 2. 贴近己方近战部队（找最近友军）
    if (myHexes.length > 0) {
      var minDistAlly = Infinity;
      for (var j = 0; j < myHexes.length; j++) {
        var da = hDist(c.hex, myHexes[j]);
        if (da < minDistAlly) minDistAlly = da;
      }
      if (minDistAlly <= 1) score += 25;
      else if (minDistAlly <= 2) score += 15;
      else if (minDistAlly <= 3) score += 5;
      else score -= (minDistAlly - 3) * 5;
    }

    if (score > bestScore) { bestScore = score; best = c; }
  }
  return best;
}

function getSlotIndexInContainer(container, slotIdx) {
  for (var i = 0; i < container.length; i++) { if (parseInt(container[i].dataset.slotIdx) === slotIdx) return i; }
  return 0;
}

function onPlayerPlacePiece() {
  if (TurnState.phase !== 'deploy') return;
  if (isControlledByAI(TurnState.currentPlayer)) return; // AI 方不接受人类放置
  TurnState.deployCount[TurnState.currentPlayer]++;
  requestRender();
  nextDeployPlayer();
}

function nextDeployPlayer() {
  if (TurnState.deployCount.player >= TurnState.totalPlayer && TurnState.deployCount.enemy >= TurnState.totalEnemy) { startBattlePhase(); return; }
  if (TurnState.currentPlayer === 'player') TurnState.currentPlayer = 'enemy'; else TurnState.currentPlayer = 'player';
  if (TurnState.currentPlayer === 'player' && TurnState.deployCount.player >= TurnState.totalPlayer) { nextDeployPlayer(); return; }
  if (TurnState.currentPlayer === 'enemy' && TurnState.deployCount.enemy >= TurnState.totalEnemy) { nextDeployPlayer(); return; }
  updateDeployUI();
}

function tryEndDeploy() {
  if (TurnState.deployCount.player >= TurnState.totalPlayer && TurnState.deployCount.enemy >= TurnState.totalEnemy) startBattlePhase();
  else nextDeployPlayer();
}

// ===== 战斗阶段 =====
function startBattlePhase() {
  TurnState.phase = 'battle';
  TurnState.currentPlayer = TurnState.firstPlayer;
  TurnState.currentRound = 1;
  // 记录后手方（非先手方），第一回合获得 30% 减伤
  TurnState.secondPlayer = TurnState.firstPlayer === 'player' ? 'enemy' : 'player';
  Object.keys(placedPieces).forEach(function(k) {
    placedPieces[k]._actionUsedThisTurn = false;
    placedPieces[k]._attackedThisTick = false;
    placedPieces[k]._wasAttackedThisTurn = false;
    placedPieces[k]._didActionThisTurn = false;
    placedPieces[k]._chargeDistance = 0;
  });
  // 第一回合开始：检测包围状态
  processTurnStart(TurnState.firstPlayer);
  // 重置记分板
  if (typeof resetScoreboard === 'function') resetScoreboard();
  
  // 斗蛐蛐模式：部署结束后自动暂停，等待玩家点击开始
  if (TurnState.isDuelBattle) {
    _spectatorPaused = true;
    _deployPauseInitial = true;
  }
  
  updateBattleUI();
  // 斗蛐蛐模式：第一回合显示回合提示
  if (TurnState.isDuelBattle) {
    showTurnNotify(TurnState.firstPlayer);
  }
  if (isControlledByAI(TurnState.currentPlayer)) {
    // 双 AI 观战模式给玩家更长观看时间（1.5s），否则 600ms；暂停时不触发
    if (!_spectatorPaused) {
      var startDelay = (TurnState.isDuelBattle && isControlledByAI('player') && isControlledByAI('enemy')) ? 1500 : 600;
      setTimeout(function() { runAITurn(TurnState.currentPlayer); }, battleDelay(startDelay));
    }
  }
}

// 回合开始处理（包围检测、主动重整）
function processTurnStart(team) {
  Object.keys(placedPieces).forEach(function(k) {
    var p = placedPieces[k];
    if (p.team !== team || p._routed) return;

    // 检测包围状态（状态型debuff：只触发一次，脱离后恢复，可再次触发）
    var enemyCount = 0;
    for (var i = 0; i < HEX_DIRS.length; i++) {
      var d = HEX_DIRS[i];
      var nk = (p.hex.q + d.q) + ',' + (p.hex.r + d.r) + ',' + (-p.hex.q - d.q - p.hex.r - d.r);
      if (placedPieces[nk] && placedPieces[nk].team !== team && !placedPieces[nk]._routed) {
        enemyCount++;
      }
    }
    var isSurrounded = enemyCount >= 3;
    var wasSurrounded = p._wasSurrounded || false;
    var udName = (unitDefByType(p.unitType) || {name: '未知'}).name;
    if (isSurrounded && !wasSurrounded) {
      // 新被包围：加debuff，士气-5（只触发一次）
      p._currentMorale = Math.max(0, (p._currentMorale || 0) - 5);
      var ud = typeof unitDefByType === 'function' ? unitDefByType(p.unitType) : null;
      if (p._neverRout || (ud && ud._neverRout)) {
        p._currentMorale = Math.max(1, p._currentMorale);
      }
      if (typeof addPieceStatus === 'function') {
        addPieceStatus(p, 'surrounded', Infinity, '⚑', '#ff6600');
      }
      addWarReportLine('[包围] ' + udName + ' 被三面以上敌军包围，士气-5！');
    } else if (!isSurrounded && wasSurrounded) {
      // 脱离包围：移除debuff，士气+5（恢复）
      p._currentMorale = Math.min(100, (p._currentMorale || 0) + 5);
      removePieceStatus(p, 'surrounded');
      addWarReportLine('[包围] ' + udName + ' 脱离包围，士气+5（恢复）');
    }
    p._wasSurrounded = isSurrounded;
  });
}

// 回合结束处理（士气恢复、状态递减）
function processTurnEnd(team) {
  Object.keys(placedPieces).forEach(function(k) {
    var p = placedPieces[k];
    if (p.team !== team || p._routed) return;

    // 方案A：回合结束自动恢复士气（未被攻击+未行动的单位+3）
    if (!p._wasAttackedThisTurn && !p._didActionThisTurn) {
      p._currentMorale = Math.min(100, (p._currentMorale || 0) + 3);
    }

    // 重置回合标记
    p._wasAttackedThisTurn = false;
    p._didActionThisTurn = false;

    // 状态回合数递减
    if (typeof tickStatuses === 'function') {
      tickStatuses(p);
    }

    var ud = typeof unitDefByType === 'function' ? unitDefByType(p.unitType) : null;
    if ((p._neverRout) || (ud && ud._neverRout)) {
      p._currentMorale = Math.max(1, p._currentMorale || 0);
    }
  });
}

function endTurn() {
  if (TurnState.phase !== 'battle') return;

  // 清除 AI 回合活跃标记（允许下个 runAITurn 重置棋子状态）
  TurnState._aiTurnActive = false;

  // 先处理当前玩家回合结束
  var currentTeam = TurnState.currentPlayer;
  processTurnEnd(currentTeam === 'player' ? 'player' : 'enemy');

  if (TurnState.currentPlayer === 'player') {
    // 切到 enemy 回合
    TurnState.currentPlayer = 'enemy';
    Object.keys(placedPieces).forEach(function(k) {
      if (placedPieces[k].team === 'enemy') {
        placedPieces[k]._actionUsedThisTurn = false;
        placedPieces[k]._attackedThisTick = false;
        placedPieces[k]._chargeDistance = 0;
      }
    });
    processTurnStart('enemy');
    updateBattleUI();
    // 显示回合提示（斗蛐蛐模式下始终显示）
    if (TurnState.isDuelBattle) {
      showTurnNotify('enemy');
    }
    // 按 controlFlag 决定是否调 AI（斗蛐蛐模式下乙方可能由人类操作）
    if (isControlledByAI('enemy')) {
      // 双 AI 观战模式给玩家更长观看时间（1.5s），否则 600ms；暂停时不触发
      if (!_spectatorPaused) {
        var switchDelay = (TurnState.isDuelBattle && isControlledByAI('player') && isControlledByAI('enemy')) ? 1500 : 600;
        setTimeout(function() { runAITurn('enemy'); }, battleDelay(switchDelay));
      }
    } else if (!TurnState.isDuelBattle) {
      // 非斗蛐蛐模式下，人类操作的敌方回合，显示提示
      showTurnNotify('enemy');
    }
  } else {
    // 切到 player 回合
    TurnState.currentPlayer = 'player';
    TurnState.currentRound++;
    Object.keys(placedPieces).forEach(function(k) {
      if (placedPieces[k].team === 'player') {
        placedPieces[k]._actionUsedThisTurn = false;
        placedPieces[k]._attackedThisTick = false;
        placedPieces[k]._chargeDistance = 0;
      }
    });
    processTurnStart('player');
    updateBattleUI();
    // 显示回合提示（斗蛐蛐模式下始终显示）
    if (TurnState.isDuelBattle) {
      showTurnNotify('player');
    }
    // 按 controlFlag 决定是否调 AI（斗蛐蛐模式下甲方可能由 AI 操作）
    if (isControlledByAI('player')) {
      // 双 AI 观战模式给玩家更长观看时间（1.5s），否则 600ms；暂停时不触发
      if (!_spectatorPaused) {
        var switchDelay2 = (TurnState.isDuelBattle && isControlledByAI('player') && isControlledByAI('enemy')) ? 1500 : 600;
        setTimeout(function() { runAITurn('player'); }, battleDelay(switchDelay2));
      }
    } else {
      showTurnNotify('player');
    }
  }
  requestRender();
}

function updateBattleUI() {
  var panel = document.getElementById('turnStatus');
  if (TurnState.phase !== 'battle') return;
  initBattleSpeedControls();
  updateBattleSpeedControlsVisibility();
  initSpectatorPauseBtn();
  updateSpectatorPauseBtnVisibility();
  if (typeof updateScoreboardUI === 'function') updateScoreboardUI();
  var dl = { easy: '简单', hard: '困难', legend: '传说' }[TurnState.difficulty] || '简单';
  var isPlayerTurn = TurnState.currentPlayer === 'player';
  var sideLabel;
  var sideName;
  if (TurnState.isDuelBattle && window._duelBattleData) {
    sideName = isPlayerTurn
      ? ((window._duelBattleData.sideA && window._duelBattleData.sideA.name) || '甲方')
      : ((window._duelBattleData.sideB && window._duelBattleData.sideB.name) || '乙方');
    sideLabel = sideName;
  } else if (TurnState.isDuelBattle) {
    sideLabel = isPlayerTurn ? '甲方' : '乙方';
  } else {
    sideLabel = isPlayerTurn ? '我方' : '敌方';
  }
  var roundInfo = '第' + TurnState.currentRound + '回合';
  // AI对战/斗蛐蛐模式不显示难度标签
  if (!TurnState.isAIBattle && !TurnState.isDuelBattle) {
    roundInfo += ' · ' + dl + '难度';
  }
  var who = isPlayerTurn ? ('🔷 ' + sideLabel + '回合（' + roundInfo + '）') : ('🔶 ' + sideLabel + '回合（' + roundInfo + '）');

  // 提示文字：斗蛐蛐模式下根据是否 AI 控制决定提示
  var isAITurn = isControlledByAI(TurnState.currentPlayer);
  var tipText;
  if (isAITurn) {
    tipText = '<span style="font-size:12px;color:#8b2500;margin-left:8px;font-weight:bold">⏳ AI 思考中...</span>';
  } else {
    tipText = '<span style="font-size:12px;color:#6b4c2a;margin-left:8px">选' + sideLabel + '棋子 → 移动（绿）或攻击（红）</span>';
  }
  var btnState = isAITurn ? 'disabled' : '';
  var btnText = isAITurn ? (sideLabel + '行动中...') : '结束回合 →';

  var wasHidden = panel.style.display !== 'flex';
  panel.innerHTML = '<div class="turn-info"><span style="font-weight:bold;font-size:17px">' + who + '</span>' + tipText + '</div>' +
    '<button class="turn-btn" ' + btnState + ' onclick="endTurn()">' + btnText + '</button>';
  panel.style.display = 'flex';

  // 回合切换动画
  if (window.gsap && !wasHidden) {
    gsap.fromTo(panel,
      { opacity: 0.7, y: -5 },
      { opacity: 1, y: 0, duration: 0.3, ease: 'power2.out' }
    );
    var turnInfo = panel.querySelector('.turn-info');
    if (turnInfo) {
      gsap.fromTo(turnInfo,
        { x: -10, opacity: 0.5 },
        { x: 0, opacity: 1, duration: 0.4, ease: 'power2.out' }
      );
    }
    var turnBtn = panel.querySelector('.turn-btn');
    if (turnBtn && isPlayerTurn) {
      gsap.fromTo(turnBtn,
        { scale: 0.9, opacity: 0.8 },
        { scale: 1, opacity: 1, duration: 0.4, ease: 'back.out(1.5)' }
      );
    }
  }
}

// ===== AI 战斗行动（已迁移到 ai-engine.js）=====

function showTurnNotify(team) {
  var el = document.getElementById('turnNotify');
  if (!el) return;
  var isPlayer = team === 'player';
  if (TurnState.isDuelBattle && window._duelBattleData) {
    var sideName = isPlayer
      ? ((window._duelBattleData.sideA && window._duelBattleData.sideA.name) || '甲方')
      : ((window._duelBattleData.sideB && window._duelBattleData.sideB.name) || '乙方');
    el.textContent = isPlayer ? ('🔷 「' + sideName + '」的回合') : ('🔶 「' + sideName + '」的回合');
  } else {
    var saveName = (typeof GameState !== 'undefined' && GameState.saveName) ? GameState.saveName : '我方';
    if (isPlayer) {
      el.textContent = '🔷 「' + saveName + '」的回合';
    } else {
      el.textContent = '🔶 敌方行动中...';
    }
  }
  el.className = 'turn-notify';
  el.style.display = 'block';
  // 强制重排触发重新进入动画
  void el.offsetWidth;
  el.classList.add('show');
  // 显示时间：斗蛐蛐模式下更短（约1秒），其他模式1.8秒
  var showDuration = TurnState.isDuelBattle ? 1000 : 1800;
  setTimeout(function() {
    el.classList.remove('show');
    el.classList.add('hide');
    setTimeout(function() {
      el.style.display = 'none';
      el.className = 'turn-notify';
    }, 300);
  }, showDuration);
}

// ===== 击杀漂浮提示 =====
function showKillNotify(atkName, defName) {
  var el = document.getElementById('killNotify');
  if (!el) {
    el = document.createElement('div');
    el.id = 'killNotify';
    el.style.cssText = 'position:fixed;top:18%;left:50%;transform:translateX(-50%);' +
      'z-index:9997;pointer-events:none;display:none;';
    document.body.appendChild(el);
  }
  el.innerHTML = '<div style="' +
    'background:linear-gradient(135deg,rgba(80,15,15,0.92),rgba(120,30,20,0.92));' +
    'border:2px solid #c44a2a;border-radius:10px;padding:12px 24px;' +
    'box-shadow:0 0 30px rgba(200,60,30,0.5),0 4px 16px rgba(0,0,0,0.5);' +
    'text-align:center;">' +
    '<div style="font-size:17px;font-weight:bold;color:#ff6b35;text-shadow:0 0 10px rgba(255,100,50,0.8);">' +
    escapeHtml(atkName) + ' <span style="color:#ccc;font-size:13px;">击溃了</span> ' + escapeHtml(defName) +
    '</div></div>';
  el.style.display = 'block';
  el.style.opacity = '0';
  void el.offsetWidth;

  if (window.gsap) {
    gsap.fromTo(el,
      { opacity: 0, y: 20, scale: 0.85 },
      { opacity: 1, y: 0, scale: 1, duration: 0.3, ease: 'back.out(1.5)' }
    );
    setTimeout(function() {
      gsap.to(el, { opacity: 0, y: -15, scale: 0.9, duration: 0.35, ease: 'power2.in', onComplete: function() {
        el.style.display = 'none';
      }});
    }, 900);
  } else {
    el.style.opacity = '1';
    el.style.transform = 'translateX(-50%)';
    setTimeout(function() {
      el.style.opacity = '0';
      setTimeout(function() { el.style.display = 'none'; }, 350);
    }, 900);
  }
}

function getPieceStats(piece) {
  var ud = unitDefByType(piece.unitType);
  if (!ud) return null;
  var st = computeStats(ud);
  if (!st) return null;
  st.baseType = ud.baseType || ud.type;
  if (piece._currentHP !== undefined) st.totalHP = piece._currentHP;
  if (piece._currentCount !== undefined) st.unitCount = piece._currentCount;
  if (piece._currentMorale !== undefined) st.morale = piece._currentMorale;
  st.hpPerUnit = (piece._currentHP && piece._currentCount)
    ? Math.ceil(piece._currentHP / piece._currentCount) : st.hpPerUnit;
  return st;
}

function initPieceRuntimeState(piece) {
  var ud = unitDefByType(piece.unitType);
  if (!ud) return;
  var st = computeStats(ud);
  if (!st) return;
  piece._currentHP = st.totalHP;
  piece._currentCount = ud.unitCount;
  piece._currentMorale = st.morale;
  piece._initialHP = st.totalHP;
  piece._initialCount = ud.unitCount;
  piece._initialMorale = st.morale;
  piece._routed = false;
  piece._actionUsedThisTurn = false;
  piece._attackedThisTick = false;
  piece._wasAttackedThisTurn = false;
  // 朝向：默认朝右，放置时会根据位置重新计算
  piece._facing = piece._facing !== undefined ? piece._facing : 0;
  // 状态系统
  piece._statuses = piece._statuses || {};
  // 记分板：每个棋子独立追踪伤害和击杀
  piece._damageDealt = 0;
  piece._kills = 0;
}
