// AI路径引导：如需查找其他文件路径和功能说明，请先查看项目根目录的 AI_PATH_GUIDE.md；每新增/修改一个文件后，必须同步更新AI_PATH_GUIDE.md
// ==================== AI 引擎系统 ====================
// 三档难度：简单 / 困难 / 传说

// ===== 六边形方向向量 =====
const AI_HEX_DIRS = [
  { q: +1, r: 0, s: -1 },
  { q: +1, r: -1, s: 0 },
  { q: 0, r: -1, s: +1 },
  { q: -1, r: 0, s: +1 },
  { q: -1, r: +1, s: 0 },
  { q: 0, r: +1, s: -1 }
];

// ===== AI 难度配置 =====
const AI_DIFFICULTY_CONFIG = {
  easy: {
    name: '简单',
    targeting: 'nearest',
    moveStyle: 'toward',
    aggression: 0.4,
    preferRanged: false,
    flankingBonus: false,
    coordinatedAttack: false,
    formationBonus: false,
    retreatWhenLow: false,
    skipChance: 0.2,
    moraleSensitive: false
  },
  hard: {
    name: '困难',
    targeting: 'smart',
    moveStyle: 'coordinated',
    aggression: 0.75,
    preferRanged: true,
    flankingBonus: true,
    coordinatedAttack: true,
    formationBonus: true,
    retreatWhenLow: false,
    skipChance: 0,
    moraleSensitive: false
  },
  legend: {
    name: '传说',
    targeting: 'tactical',
    moveStyle: 'legend',
    aggression: 0.95,
    preferRanged: true,
    flankingBonus: true,
    coordinatedAttack: true,
    formationBonus: true,
    retreatWhenLow: false,
    skipChance: 0,
    moraleSensitive: true,
    moraleRetreat: false
  }
};

// 兼容旧代码的难度映射
var DIFF_MAP = {
  low: 'easy', medium: 'easy', high: 'hard', extreme: 'legend',
  easy: 'easy', hard: 'hard', legend: 'legend'
};

// ===== AI 状态追踪 =====
var AIState = {
  difficulty: 'easy',
  config: null,
  assignedTargets: {},
  actedThisTurn: new Set(),
  formationCenter: null,
  focusedTargetKey: null  // 传说难度：集火目标
};

// ===== 远程武器识别辅助函数 =====
function isRangedWeapon(st) {
  var t = st && st.mainWeapon && st.mainWeapon.type;
  return t === 'bow' || t === 'crossbow';
}

// ===== 获取当前难度配置 =====
function getAIConfig(difficulty) {
  var rawDiff = difficulty || TurnState.difficulty || 'easy';
  var diff = DIFF_MAP[rawDiff] || rawDiff || 'easy';
  // 优先从 difficulty_config.json 读取
  if (window.DC && window.DC.levels && window.DC.levels[diff] && window.DC.levels[diff].ai) {
    var dcAI = window.DC.levels[diff].ai;
    return {
      name: window.DC.levels[diff].label || diff,
      targeting: dcAI.targeting || 'nearest',
      moveStyle: dcAI.moveStyle || 'toward',
      aggression: dcAI.aggression !== undefined ? dcAI.aggression : 0.5,
      preferRanged: dcAI.preferRanged || false,
      flankingBonus: dcAI.flankingBonus || false,
      coordinatedAttack: dcAI.coordinatedAttack || false,
      formationBonus: dcAI.formationBonus || false,
      retreatWhenLow: dcAI.retreatWhenLow || false,
      skipChance: dcAI.skipChance || 0,
      moraleSensitive: dcAI.moraleSensitive || false,
      moraleRetreat: false
    };
  }
  return AI_DIFFICULTY_CONFIG[diff] || AI_DIFFICULTY_CONFIG.easy;
}

// ===== 初始化AI状态 =====
function initAIState(difficulty) {
  var rawDiff = difficulty || 'easy';
  var diff = DIFF_MAP[rawDiff] || rawDiff || 'easy';
  AIState.difficulty = diff;
  AIState.config = getAIConfig(diff);
  AIState.assignedTargets = {};
  AIState.actedThisTurn.clear();
  AIState.formationCenter = null;
  AIState.focusedTargetKey = null;
  // 传说难度：开局选定集火目标（最弱的可攻击目标）
  if (diff === 'legend') {
    AIState.focusedTargetKey = null; // 在回合中动态更新
  }
}

// ===== 目标选择策略 =====

// 最近目标（简单难度）
function aiTargetNearest(aiUnit, enemies) {
  var best = null, bestDist = Infinity;
  enemies.forEach(function(e) {
    if (e.piece._routed) return;
    var d = hDist(aiUnit.piece.hex, e.piece.hex);
    if (d < bestDist) { bestDist = d; best = e; }
  });
  return best;
}

// 智能目标选择（困难难度：血量低优先 + 远程优先 + 距离）
function aiTargetSmart(aiUnit, enemies) {
  var config = AIState.config;
  var valid = enemies.filter(function(e) { return !e.piece._routed; });
  if (valid.length === 0) return null;

  var best = null, bestScore = -Infinity;

  valid.forEach(function(e) {
    var score = 0;
    var dist = hDist(aiUnit.piece.hex, e.piece.hex);
    var enemySt = getPieceStats(e.piece);

    // 1. 血量低优先（容易击杀）
    var hpRatio = e.piece._currentHP / Math.max(1, e.piece._initialHP);
    if (hpRatio < 0.3) score += 35;
    else if (hpRatio < 0.5) score += 20;
    else if (hpRatio < 0.7) score += 8;

    // 2. 距离近优先
    if (dist <= 1) score += 18;
    else if (dist <= 2) score += 10;
    else if (dist <= 3) score += 4;

    // 3. 远程单位优先（先干掉输出）
    if (isRangedWeapon(enemySt)) {
      score += config.preferRanged ? 22 : 10;
    }

    // 4. 溃逃单位优先
    // (已移除 aiTargetSmart 死分支：if (e.piece._routed) score += 15;)

    // 5. 血量比例
    score += (1 - hpRatio) * 30;

    if (score > bestScore) {
      bestScore = score;
      best = e;
    }
  });

  return best;
}

// 战术目标选择（传说难度：按照优先级 能击溃>能击杀>3集火>降士气>降血量>防守>2集火>自保）
function aiTargetTactical(aiUnit, enemies) {
  var config = AIState.config;
  var valid = enemies.filter(function(e) { return !e.piece._routed; });
  if (valid.length === 0) return null;

  var st = getPieceStats(aiUnit.piece);
  var best = null, bestScore = -Infinity;

  valid.forEach(function(e) {
    var score = 0;
    var enemySt = getPieceStats(e.piece);
    var dist = hDist(aiUnit.piece.hex, e.piece.hex);
    var atkRange = (st && st.allowedRange) ? st.allowedRange : 1;
    var canReach = (dist <= atkRange);
    var canReachAfterMove = (dist <= atkRange + (st ? st.movement || 3 : 3));

    if (!st) return;

    // 估算伤害（与 combat.js fullDamage 公式一致）
    var mainWeapon = st.mainWeapon;
    var estimatedHpDmg = (mainWeapon ? mainWeapon.baseDamage || 10 : 10) * (st.attackRange || 1) * (st.unitCount || 1);
    var estMoraleDmg = 5;  // 与 combat.js L572 一致（固定 -5 士气）

    // 第1优先级：能击溃（HP击杀 或 士气击溃）
    var canKill = e.piece._currentHP <= estimatedHpDmg || e.piece._currentMorale <= estMoraleDmg;
    if (canKill) {
      score += 500;
      if (canReach) score += 200;
    }

    // 第3优先级：多人集火同一目标（3+）
    if (config.coordinatedAttack && AIState.assignedTargets[e.key]) {
      var focusCount = AIState.assignedTargets[e.key].count;
      if (focusCount >= 3) score += 120;
      else if (focusCount >= 2) score += 50;
    }

    // 第4优先级：能造成高士气伤害（士气降到危险线）
    if (e.piece._currentMorale !== undefined && e.piece._initialMorale !== undefined) {
      var moraleRatio = e.piece._currentMorale / Math.max(1, e.piece._initialMorale);
      if (moraleRatio < 0.3) score += 60;  // 士气已崩溃边缘
      else if (moraleRatio < 0.5) score += 40;  // 士气危险
      else if (moraleRatio < 0.7) score += 15;  // 士气偏低
    }

    // 第5优先级：高血量伤害
    if (e.piece._currentHP && e.piece._initialHP) {
      var hpRatio = e.piece._currentHP / e.piece._initialHP;
      if (hpRatio < 0.3) score += 70;
      else if (hpRatio < 0.5) score += 40;
      else if (hpRatio > 0.8) score += 10; // 杀满血的也有价值
    }

    // 第6优先级：远程/高威胁单位优先
    if (isRangedWeapon(enemySt)) {
      score += 25;
      if (dist <= 3) score += 15; // 远程就在附近，危险
    }

    // 距离修正：越近越容易攻击
    if (canReach) score += 30;
    else if (canReachAfterMove) score += 15;

    // 骑兵特化：侧袭背袭得分翻倍
    var ud_piece = unitDefByType(aiUnit.piece.unitType);
    var pieceBaseType = ud_piece ? (ud_piece.baseType || ud_piece.type) : '';
    if (pieceBaseType === 'cavalry' || pieceBaseType === 'flying') {
      score += 10; // 骑兵倾向任何目标
    }

    if (score > bestScore) {
      bestScore = score;
      best = e;
    }
  });

  return best;
}

// 随机选择
function aiTargetRandom(enemies) {
  var valid = enemies.filter(function(e) { return !e.piece._routed; });
  if (valid.length === 0) return null;
  return valid[Math.floor(Math.random() * valid.length)];
}

// 主目标选择函数
function aiSelectTarget(aiUnit, enemies) {
  var strategy = AIState.config ? AIState.config.targeting : 'nearest';
  switch (strategy) {
    case 'smart': return aiTargetSmart(aiUnit, enemies);
    case 'tactical': return aiTargetTactical(aiUnit, enemies);
    case 'nearest':
    default: return aiTargetNearest(aiUnit, enemies);
  }
}

// ===== 移动策略 =====

// 获取所有可用移动位置（BFS）
function aiGetMoveCandidates(aiUnit, maxSteps) {
  var st = getPieceStats(aiUnit.piece);
  var isFlying = st && st.baseType === 'flying';
  var actualMove = st ? st.movement : 1;
  var steps = Math.min(maxSteps, actualMove);
  return getReachableHexes(aiUnit.piece.hex, steps, isFlying, aiUnit.piece.team);
}

// 朝向目标移动（简单难度使用）
function aiMoveToward(aiUnit, target) {
  var st = getPieceStats(aiUnit.piece);
  var maxSteps = st ? st.movement : 1;
  var candidates = aiGetMoveCandidates(aiUnit, maxSteps);
  if (candidates.length === 0) return null;

  var best = null, bestDist = Infinity;
  candidates.forEach(function(c) {
    var d = hDist(c.hex, target.piece.hex);
    if (d < bestDist) { bestDist = d; best = c; }
  });
  return best;
}

// 困难难度：背袭>侧袭>正击 + 血量<40%时保守（不冒险走位）
function aiMoveCoordinated(aiUnit, target, allies, enemies) {
  var config = AIState.config;
  var st = getPieceStats(aiUnit.piece);
  var maxSteps = st ? st.movement : 1;
  var candidates = aiGetMoveCandidates(aiUnit, maxSteps);
  if (candidates.length === 0) return null;

  var hpRatio = aiUnit.piece._currentHP !== undefined && aiUnit.piece._initialHP !== undefined
    ? aiUnit.piece._currentHP / Math.max(1, aiUnit.piece._initialHP) : 1;
  var isConservative = hpRatio < 0.4; // 血量<40% = 害怕被偷袭
  var isRanged = isRangedWeapon(st);
  var myRange = st ? (st.allowedRange || 1) : 1;

  var best = null, bestScore = -Infinity;

  candidates.forEach(function(c) {
    var score = 0;
    var distToTarget = hDist(c.hex, target.piece.hex);
    var canAttack = distToTarget <= myRange;

    if (isConservative) {
      // ===== 保守模式：避免冒险，优先挨着友军 + 保持距离 =====
      // 1. 抱团：紧贴友军中心
      if (config.formationBonus && AIState.formationCenter) {
        var distToCenter = hDist(c.hex, AIState.formationCenter);
        score -= distToCenter * 5;
      }
      // 2. 远离敌人
      var minDistToEnemy = Infinity;
      enemies.forEach(function(e) {
        if (e.piece._routed) return;
        var d = hDist(c.hex, e.piece.hex);
        if (d < minDistToEnemy) minDistToEnemy = d;
      });
      score += minDistToEnemy * 6;
      // 3. 能攻击到就小加分（站桩输出）
      if (canAttack) score += 15;
      // 4. 弓兵保持距离
      if (isRanged && distToTarget < 2) score -= 20;
    } else {
      // ===== 攻击模式：走位背袭>侧袭>正击 =====
      // 1. 走位质量（权重最高）
      if (config.flankingBonus && typeof getAttackAzimuth === 'function' && target.piece._facing !== undefined) {
        var az = getAttackAzimuth(c.hex, target.piece.hex, target.piece._facing);
        if (az === 'rear') {
          score += 50;
          if (canAttack) score += 25;
        } else if (az === 'flank') {
          score += 28;
          if (canAttack) score += 15;
        } else {
          if (canAttack) score += 8;
        }
      } else {
        if (canAttack) score += 20;
      }
      // 2. 靠近目标（次要）
      score -= distToTarget * 3;
      // 3. 抱团
      if (config.formationBonus && AIState.formationCenter) {
        var distToCenter2 = hDist(c.hex, AIState.formationCenter);
        score -= distToCenter2 * 2;
      }
      // 4. 弓兵保持距离
      if (isRanged) {
        if (distToTarget < 2) score -= 25;
        else if (distToTarget >= 2 && distToTarget <= 4) score += 12;
      }
      // 5. 骑兵冲锋
      if (st && (st.baseType === 'cavalry' || st.baseType === 'flying')) {
        if (distToTarget <= 3) score += 10;
      }
    }

    if (score > bestScore) {
      bestScore = score;
      best = c;
    }
  });

  return best;
}

// 传说难度：分兵种走位 + 集火 + 骑兵切后排
function aiMoveLegend(aiUnit, target, allies, enemies) {
  var config = AIState.config;
  var st = getPieceStats(aiUnit.piece);
  var maxSteps = st ? st.movement : 1;
  var candidates = aiGetMoveCandidates(aiUnit, maxSteps);
  if (candidates.length === 0) return null;

  st = getPieceStats(aiUnit.piece);
  var best = null, bestScore = -Infinity;
  var myRange = st ? (st.allowedRange || 1) : 1;
  var baseType = st ? (st.baseType || 'infantry') : 'infantry';
  var isRanged = isRangedWeapon(st);
  var hpRatio = aiUnit.piece._currentHP !== undefined && aiUnit.piece._initialHP !== undefined
    ? aiUnit.piece._currentHP / Math.max(1, aiUnit.piece._initialHP) : 1;

  candidates.forEach(function(c) {
    var score = 0;
    var distToTarget = hDist(c.hex, target.piece.hex);
    var canAttack = distToTarget <= myRange;
    var az = 'front';
    if (typeof getAttackAzimuth === 'function' && target.piece._facing !== undefined) {
      az = getAttackAzimuth(c.hex, target.piece.hex, target.piece._facing);
    }

    if (baseType === 'cavalry' || baseType === 'flying') {
      // ===== 骑兵/空军：原逻辑，血再低也冲 =====
      if (az === 'rear') {
        score += 70;
        if (canAttack) score += 35;
      } else if (az === 'flank') {
        score += 40;
        if (canAttack) score += 20;
      } else {
        if (canAttack) score += 10;
      }
      score -= distToTarget * 2 + (hpRatio < 0.2 ? 0 : 0); // 残血不减分
      // 切后排远程
      enemies.forEach(function(e) {
        if (e.piece._routed) return;
        var eSt = getPieceStats(e.piece);
        if (isRangedWeapon(eSt)) {
          var d2 = hDist(c.hex, e.piece.hex);
          if (d2 <= 3) score += 18;
          if (d2 <= myRange) score += 30;
        }
      });

    } else if (isRanged) {
      // ===== 远程：侧袭>正击>自己不会被打>背击 =====
      // 1. 检测新位置是否会遭到反击
      var canBeCountered = false;
      enemies.forEach(function(e) {
        if (e.piece._routed) return;
        var eSt = getPieceStats(e.piece);
        if (!eSt) return;
        var eRange = eSt.allowedRange || 1;
        if (hDist(c.hex, e.piece.hex) <= eRange) canBeCountered = true;
      });

      if (az === 'flank') {
        score += 45;
        if (canAttack) score += 25;
      } else if (az === 'rear') {
        score += 30;
        if (canAttack) score += 15;
      } else {
        if (canAttack) score += 18;
      }
      if (!canBeCountered) score += 20; // 安全位加分
      score -= distToTarget * 2;
      // 保持2-3格距离
      if (distToTarget < 2) score -= 20;
      else if (distToTarget >= 2 && distToTarget <= 4) score += 10;
      // 抱团
      if (config.formationBonus && AIState.formationCenter) {
        var distR = hDist(c.hex, AIState.formationCenter);
        score -= distR * 2;
      }

    } else {
      // ===== 近战步兵：稳固防线，侧袭优先>正击>背击（背袭可能离战线太远）=====
      if (az === 'flank') {
        score += 50;
        if (canAttack) score += 30;
      } else if (az === 'rear') {
        score += 15;  // 背袭权重低，不能离开战线
        if (canAttack) score += 10;
      } else {
        if (canAttack) score += 22;  // 正击也很好（稳固）
      }
      score -= distToTarget * 2;
      // 抱团权重高（保护后排）
      if (config.formationBonus && AIState.formationCenter) {
        var distM = hDist(c.hex, AIState.formationCenter);
        score -= distM * 3;
      }
      // 离己方远程近（保护它们）
      allies.forEach(function(a) {
        if (a.piece._routed) return;
        var aSt = getPieceStats(a.piece);
        if (isRangedWeapon(aSt)) {
          var da = hDist(c.hex, a.piece.hex);
          if (da <= 2) score += 12;
        }
      });
      // 骑兵冲锋加成（如果这个近战是骑步混编的possibility）
      if (distToTarget <= 2) score += 5;
    }

    // 通用：集火
    if (config.coordinatedAttack && AIState.focusedTargetKey) {
      var focusedEnemy = enemies.find(function(e) { return e.key === AIState.focusedTargetKey; });
      if (focusedEnemy) {
        var distToFocused = hDist(c.hex, focusedEnemy.piece.hex);
        if (distToFocused <= myRange) score += 12;
        score -= distToFocused * 2;
      }
    }

    // 传说难度：孤军深入风险评估
    // 敌方可攻击范围 = 敌方移动距离 + 攻击距离（敌方一回合内能攻击到的范围）
    // 友方可防御范围 = 友方移动距离（友方一回合内能移动到支援的范围）
    // 若目标位置在3+敌方攻击范围内且不在任何友方防御范围内 → 高风险惩罚
    var enemyThreatCount = 0;
    for (var eti = 0; eti < enemies.length; eti++) {
      var eUnit = enemies[eti];
      if (eUnit.piece._routed) continue;
      var eSt = getPieceStats(eUnit.piece);
      if (!eSt) continue;
      var eMove = eSt.movement || 1;
      var eAtk = eSt.allowedRange || 1;
      var eThreatRange = eMove + eAtk;
      if (hDist(c.hex, eUnit.piece.hex) <= eThreatRange) {
        enemyThreatCount++;
      }
    }
    var inAllySupport = false;
    for (var asi = 0; asi < allies.length; asi++) {
      var aUnit = allies[asi];
      if (aUnit.piece._routed) continue;
      if (aUnit.key === aiUnit.key) continue;
      var aSt = getPieceStats(aUnit.piece);
      if (!aSt) continue;
      var aMove = aSt.movement || 1;
      var aSupportRange = aMove;
      if (hDist(c.hex, aUnit.piece.hex) <= aSupportRange) {
        inAllySupport = true;
        break;
      }
    }
    if (enemyThreatCount >= 3 && !inAllySupport) {
      score -= 120;
    }

    if (score > bestScore) {
      bestScore = score;
      best = c;
    }
  });

  return best;
}

// ===== 士气崩溃撤退：远离所有敌人，靠近友方撤退 =====
function aiFindRetreat(aiUnit, enemies, allies) {
  var st = getPieceStats(aiUnit.piece);
  var maxSteps = st ? st.movement : 1;
  var candidates = aiGetMoveCandidates(aiUnit, maxSteps);
  if (candidates.length === 0) return null;

  var best = null, bestScore = -Infinity;
  candidates.forEach(function(c) {
    var score = 0;

    // 远离所有敌人（安全第一）
    var minDistToEnemy = Infinity;
    enemies.forEach(function(e) {
      if (e.piece._routed) return;
      var d = hDist(c.hex, e.piece.hex);
      if (d < minDistToEnemy) minDistToEnemy = d;
    });
    score += minDistToEnemy * 8;

    // 靠近友方（重整）
    var minDistToAlly = Infinity;
    allies.forEach(function(a) {
      if (a.piece._routed) return;
      var d = hDist(c.hex, a.piece.hex);
      if (d < minDistToAlly) minDistToAlly = d;
    });
    if (minDistToAlly < Infinity) score -= minDistToAlly * 2;

    if (score > bestScore) { bestScore = score; best = c; }
  });
  return best;
}

// 检查是否有可击杀目标（本次攻击可击溃）
function aiFindKillableTarget(aiUnit, enemies, st) {
  if (!st) return null;
  for (var i = 0; i < enemies.length; i++) {
    var e = enemies[i];
    if (e.piece._routed) continue;
    if (!aiCanAttack(aiUnit, e, st)) continue;
    // 估算伤害：用 computeCombatPreview 或简单估算
    var defSt = getPieceStats(e.piece);
    if (!defSt) continue;
    var atkBase = st.mainBase || (st.mainWeapon ? st.mainWeapon.baseDamage : 10);
    var atkAP = st.mainAP || (st.mainWeapon ? st.mainWeapon.armorPierce : 0);
    var effArmor = defSt.totalArmor || 0;
    var rawDmg = atkBase - effArmor;
    if (isNaN(rawDmg)) rawDmg = atkAP || 1;
    if (rawDmg < atkAP) rawDmg = atkAP;
    if (rawDmg < 1) rawDmg = 1;
    var atkRangeVal = st.attackRange || 1;
    var atkCount = aiUnit.piece._currentCount || 1;
    var fullDamage = rawDmg * atkRangeVal * atkCount;
    // 如果预估伤害 >= 目标当前HP，则可击杀
    if (fullDamage >= (e.piece._currentHP || 0)) {
      return e;
    }
  }
  return null;
}

// 骑兵/飞兵被近身时是否应勇敢冲锋（不撤退切后排）
// 条件：当前被敌方近身 且 血量>50% 且 士气>30
function aiShouldBeBrave(aiUnit, enemies) {
  var hp = aiUnit.piece._currentHP;
  var maxHP = aiUnit.piece._initialHP;
  var morale = aiUnit.piece._currentMorale;
  if (hp === undefined || maxHP === undefined || morale === undefined) return false;
  if (hp / maxHP <= 0.5) return false;
  if (morale <= 30) return false;
  // 必须当前被敌方近身（1格内有敌人）
  var pinned = false;
  for (var i = 0; i < enemies.length; i++) {
    if (enemies[i].piece._routed) continue;
    if (hDist(aiUnit.piece.hex, enemies[i].piece.hex) <= 1) { pinned = true; break; }
  }
  return pinned;
}

// 检查某格是否在敌方近战步兵1格内
function aiIsAdjacentToInfantry(hex, enemies) {
  for (var i = 0; i < enemies.length; i++) {
    if (enemies[i].piece._routed) continue;
    if (hDist(hex, enemies[i].piece.hex) > 1) continue;
    var eUd = unitDefByType(enemies[i].piece.unitType);
    if (eUd && eUd.baseType === 'infantry') return true;
  }
  return false;
}

// 评估某格的通道状况：区分"战术卡位"（站在出口挡住敌人）和"钻入死胡同"（进通道内部被卡）
function aiEvaluatePositionBottleneck(hex, st, aiUnit, enemies) {
  var passableCount = 0;
  var passableDirs = [];
  var blockedByTerrainCount = 0;
  var isFlying = false;
  if (aiUnit) {
    var myUd = unitDefByType(aiUnit.piece.unitType);
    isFlying = myUd && myUd.baseType === 'flying';
  }
  for (var i = 0; i < AI_HEX_DIRS.length; i++) {
    var d = AI_HEX_DIRS[i];
    var nq = hex.q + d.q;
    var nr = hex.r + d.r;
    var ns = hex.s + d.s;
    var nkey = nq + ',' + nr + ',' + ns;
    var terrainBlocked = typeof isTerrainBlocked === 'function' ? isTerrainBlocked({q: nq, r: nr, s: ns}) : false;
    var piece = BoardAPI.getPiece(nkey);
    // 检查地形是否可通行
    var isBlocked = false;
    if (terrainBlocked) {
      blockedByTerrainCount++;
      if (!isFlying) isBlocked = true;
    }
    // 检查是否有其他单位阻挡
    if (piece && !piece._routed && piece !== aiUnit.piece) {
      isBlocked = true;
    }
    if (!isBlocked) {
      passableCount++;
      passableDirs.push({ q: nq, r: nr, s: ns });
    }
  }

  var isBottleneck = passableCount <= 2 && blockedByTerrainCount >= 2;

  // 判断是否为"战术卡位"：站在通道出口（仅1-2个可通行方向），且至少一个方向有敌方单位正在靠近
  var isTacticalChoke = false;
  if (isBottleneck && enemies && enemies.length > 0) {
    // 检查可通行方向上是否有敌方单位（敌方在通道另一侧想过来）
    for (var pi = 0; pi < passableDirs.length; pi++) {
      var dir = passableDirs[pi];
      for (var ei = 0; ei < enemies.length; ei++) {
        if (enemies[ei].piece._routed) continue;
        var ed = hDist(dir, enemies[ei].piece.hex);
        // 敌方在可通行方向的2-4格内，说明他们想从这条路过来
        if (ed <= 4) {
          isTacticalChoke = true;
          break;
        }
      }
      if (isTacticalChoke) break;
    }
  }

  // 判断是否为"钻入通道内部"：可通行方向少，且周围大量地形阻挡，但不在出口
  var isDeadEnd = isBottleneck && !isTacticalChoke && passableCount <= 1;

  return {
    passable: passableCount,
    total: 6,
    isBottleneck: isBottleneck,
    isTacticalChoke: isTacticalChoke,
    isDeadEnd: isDeadEnd
  };
}

// 检查移动距离+攻击距离范围内是否有可击杀目标
function aiFindKillableInRange(aiUnit, enemies, st) {
  if (!st) return null;
  var myMove = st.movement || 1;
  var myAtkRange = st.allowedRange || 1;
  var totalReach = myMove + myAtkRange;
  for (var i = 0; i < enemies.length; i++) {
    var e = enemies[i];
    if (e.piece._routed) continue;
    // 移动+攻击范围内能打到
    if (hDist(aiUnit.piece.hex, e.piece.hex) > totalReach) continue;
    // 估算伤害
    var defSt = getPieceStats(e.piece);
    if (!defSt) continue;
    var atkBase = st.mainBase || (st.mainWeapon ? st.mainWeapon.baseDamage : 10);
    var atkAP = st.mainAP || (st.mainWeapon ? st.mainWeapon.armorPierce : 0);
    var effArmor = defSt.totalArmor || 0;
    var rawDmg = atkBase - effArmor;
    if (isNaN(rawDmg)) rawDmg = atkAP || 1;
    if (rawDmg < atkAP) rawDmg = atkAP;
    if (rawDmg < 1) rawDmg = 1;
    var atkRangeVal = st.attackRange || 1;
    var atkCount = aiUnit.piece._currentCount || 1;
    var fullDamage = rawDmg * atkRangeVal * atkCount;
    if (fullDamage >= (e.piece._currentHP || 0)) {
      return e;
    }
  }
  return null;
}

// 弓兵保护逻辑（困难+传说共用）
function aiRangerFindCover(aiUnit, enemies) {
  var st = getPieceStats(aiUnit.piece);
  if (!st || !st.mainWeapon || st.mainWeapon.type !== 'bow') return null;

  var actualMove = st ? st.movement : 1;
  var maxSteps = actualMove;
  var candidates = aiGetMoveCandidates(aiUnit, maxSteps);
  if (candidates.length === 0) return null;

  // 被贴脸时逃跑
  var surrounded = false;
  enemies.forEach(function(e) {
    if (!e.piece._routed && hDist(aiUnit.piece.hex, e.piece.hex) <= 1) surrounded = true;
  });
  if (surrounded) {
    var best = null, bestSafety = -Infinity;
    candidates.forEach(function(c) {
      var minDist = Infinity;
      enemies.forEach(function(e) {
        if (e.piece._routed) return;
        var d = hDist(c.hex, e.piece.hex);
        if (d < minDist) minDist = d;
      });
      if (minDist > bestSafety) { bestSafety = minDist; best = c; }
    });
    return best;
  }

  // 保持理想距离（能打到人的前提下），未达到则全速靠近
  var best = null, bestScore = -Infinity;
  var myRange = st.mainWeapon.allowedRange || 1;
  var idealDist = Math.max(2, myRange - 1);
  candidates.forEach(function(c) {
    var minDist = Infinity;
    var minDistEnemy = null;
    enemies.forEach(function(e) {
      if (e.piece._routed) return;
      var d = hDist(c.hex, e.piece.hex);
      if (d < minDist) { minDist = d; minDistEnemy = e; }
    });
    if (!isFinite(minDist)) { minDist = 99; } // 没有活着的敌人时，统一用大数
    var score = 0;
    // 能打到敌人：大幅加分
    if (minDist <= myRange) score += 30;
    // 离理想距离越近越好（两端都扣分，但远处对称bug已消除，改用递减公式）
    var distError = Math.abs(minDist - idealDist);
    score -= distError * 3;  // 远离2.5的每一步扣3分，打破对称
    // 略微偏好靠近敌人（远处时确保方向正确）
    score -= minDist * 0.5;
    if (score > bestScore) { bestScore = score; best = c; }
  });
  return best;
}

// ===== 指挥官统筹层：回合开始时评估全局，输出战术方针和行动顺序 =====
function aiCommanderPlan(enemyPieces, playerPieces) {
  var config = AIState.config;
  var difficulty = AIState.difficulty;

  // 简单难度不做战术评估，直接按"必逃→必杀→必攻→其它"排序
  if (difficulty === 'easy') {
    var easyOrder = aiSortActionOrder(enemyPieces, playerPieces, null);
    return {
      tactic: 'aggressive',
      focusTargetKey: null,
      threatPriority: [],
      protectList: [],
      actionOrder: easyOrder
    };
  }

  // ===== Hard/Legend：战术方针判定 =====
  var tactic = 'aggressive';
  var focusTargetKey = null;
  var threatPriority = [];
  var protectList = [];

  // 1. 统计玩家远程单位
  var playerRanged = [];
  var playerCavalry = [];
  playerPieces.forEach(function(p) {
    if (p.piece._routed) return;
    var pst = getPieceStats(p.piece);
    if (isRangedWeapon(pst)) {
      playerRanged.push(p);
    }
    var ud = unitDefByType(p.piece.unitType);
    var bt = ud ? (ud.baseType || ud.type) : '';
    if (bt === 'cavalry' || bt === 'flying') playerCavalry.push(p);
  });

  // 2. 统计我方骑兵/空军（用于切后排）
  var myFlankers = [];
  enemyPieces.forEach(function(e) {
    if (e.piece._routed) return;
    var ud = unitDefByType(e.piece.unitType);
    var bt = ud ? (ud.baseType || ud.type) : '';
    if (bt === 'cavalry' || bt === 'flying') myFlankers.push(e);
  });

  // 3. 找玩家残血单位（HP%<30%）
  var weakestPlayer = null;
  var weakestRatio = 1.0;
  playerPieces.forEach(function(p) {
    if (p.piece._routed) return;
    if (!p.piece._currentHP || !p.piece._initialHP) return;
    var r = p.piece._currentHP / p.piece._initialHP;
    if (r < weakestRatio) { weakestRatio = r; weakestPlayer = p; }
  });

  // 4. 我方总 HP%
  var myTotalHP = 0, myMaxHP = 0;
  enemyPieces.forEach(function(e) {
    if (e.piece._routed) return;
    myTotalHP += (e.piece._currentHP || 0);
    myMaxHP += (e.piece._initialHP || 1);
  });
  var myHPRatio = myMaxHP > 0 ? myTotalHP / myMaxHP : 1;

  // ===== 战术方针判定（按优先级） =====
  // 优先级 1: 玩家有远程 + 我方有骑兵/空军 → focus_ranged
  if (playerRanged.length > 0 && myFlankers.length > 0) {
    tactic = 'focus_ranged';
    // 集火目标：玩家远程中血量最低的
    var weakestRanged = null, wrRatio = 1.0;
    playerRanged.forEach(function(p) {
      var r = p.piece._currentHP / Math.max(1, p.piece._initialHP);
      if (r < wrRatio) { wrRatio = r; weakestRanged = p; }
    });
    if (weakestRanged) focusTargetKey = weakestRanged.key;
  }
  // 优先级 2: 玩家有残血单位 → focus_weak
  else if (weakestPlayer && weakestRatio < 0.3) {
    tactic = 'focus_weak';
    focusTargetKey = weakestPlayer.key;
  }
  // 优先级 3: 我方总 HP%<60% → defensive
  else if (myHPRatio < 0.6) {
    tactic = 'defensive';
  }
  // 默认 aggressive
  else {
    tactic = 'aggressive';
    if (weakestPlayer && weakestRatio < 0.5) focusTargetKey = weakestPlayer.key;
  }

  // ===== 威胁排序（玩家远程 > 骑兵 > 步兵） =====
  threatPriority = playerPieces.slice().sort(function(a, b) {
    if (a.piece._routed) return 1;
    if (b.piece._routed) return -1;
    var aIsRanged = false, bIsRanged = false;
    var aSt = getPieceStats(a.piece);
    var bSt = getPieceStats(b.piece);
    if (isRangedWeapon(aSt)) aIsRanged = true;
    if (isRangedWeapon(bSt)) bIsRanged = true;
    if (aIsRanged && !bIsRanged) return -1;
    if (!aIsRanged && bIsRanged) return 1;
    return 0;
  }).map(function(p) { return p.key; });

  // ===== 保护清单（残血弓兵、被贴脸的我方单位） =====
  enemyPieces.forEach(function(e) {
    if (e.piece._routed) return;
    var eSt = getPieceStats(e.piece);
    var isRanged = isRangedWeapon(eSt);
    var hpRatio = e.piece._currentHP && e.piece._initialHP ? e.piece._currentHP / e.piece._initialHP : 1;
    var isPinned = false;
    playerPieces.forEach(function(p) {
      if (p.piece._routed) return;
      if (hDist(e.piece.hex, p.piece.hex) <= 1) isPinned = true;
    });
    if (isRanged && (hpRatio < 0.4 || isPinned)) protectList.push(e.key);
  });

  // ===== 动态行动顺序 =====
  var actionOrder = aiSortActionOrder(enemyPieces, playerPieces, {
    tactic: tactic,
    focusTargetKey: focusTargetKey,
    myFlankers: myFlankers
  });

  return {
    tactic: tactic,
    focusTargetKey: focusTargetKey,
    threatPriority: threatPriority,
    protectList: protectList,
    actionOrder: actionOrder
  };
}

// ===== 行动顺序排序：必逃→必杀→必攻→配合移动→推进→站桩 =====
function aiSortActionOrder(enemyPieces, playerPieces, plan) {
  var order = [];

  // 每个单位计算优先级分数
  var scored = enemyPieces.map(function(ep) {
    if (ep.piece._routed) return { ep: ep, score: -1 };
    var st = getPieceStats(ep.piece);
    if (!st) return { ep: ep, score: -1 };
    var role = aiClassify(ep, st);
    var myRange = st.allowedRange || 1;
    var score = 50; // 基础分

    // 1. 必逃：被贴脸的弓兵
    if (role === 'bow') {
      var pinned = false;
      playerPieces.forEach(function(p) {
        if (p.piece._routed) return;
        if (hDist(ep.piece.hex, p.piece.hex) <= 1) pinned = true;
      });
      if (pinned) score += 1000;
    }

    // 2. 必杀：能一击击杀敌人
    var canKill = false;
    playerPieces.forEach(function(p) {
      if (p.piece._routed) return;
      if (hDist(ep.piece.hex, p.piece.hex) > myRange) return;
      var est = (st.mainWeapon ? st.mainWeapon.baseDamage || 10 : 10) * (st.unitCount || 1);
      if (p.piece._currentHP && p.piece._currentHP <= est) canKill = true;
    });
    if (canKill) score += 800;

    // 3. 必攻：能攻击且指挥官指定目标可达
    if (plan && plan.focusTargetKey) {
      var focused = playerPieces.find(function(p) { return p.key === plan.focusTargetKey; });
      if (focused && !focused.piece._routed) {
        var d = hDist(ep.piece.hex, focused.piece.hex);
        if (d <= myRange) score += 600;
        else if (d <= myRange + (st.movement || 3)) score += 300;
      }
    }

    // 4. 配合移动：切后排（tactic=focus_ranged 时，骑兵/空军提前）
    if (plan && plan.tactic === 'focus_ranged' && (role === 'cavalry' || role === 'flying')) {
      score += 400;
    }

    // 5. 推进：步兵前线推进（敌人在视野内时优先级提升）
    if (role === 'infantry' || role === 'beast') {
      var minDist = Infinity;
      playerPieces.forEach(function(p) {
        if (p.piece._routed) return;
        var d = hDist(ep.piece.hex, p.piece.hex);
        if (d < minDist) minDist = d;
      });
      if (minDist <= 3) score += 100;
    }

    // 6. 站桩：远程原地输出（默认基础分）
    // 不额外加分

    return { ep: ep, score: score };
  });

  scored.sort(function(a, b) { return b.score - a.score; });
  scored.forEach(function(s) {
    if (s.score >= 0) order.push(s.ep);
  });
  return order;
}

// ===== 兵种分类 =====
// 弓兵(bow): 惧怕近身，远程输出
// 弩兵(crossbow): 无惧怕近身，远程输出
// 骑兵(cavalry): 游走士气打击，侧袭背袭
// 步兵(infantry): 抗线推进，抱团
// 空军(flying): 类似骑兵，优先切远程兵
// 野兽(beast): 类似步兵，正面冲
function aiClassify(aiUnit, st) {
  var wpType = st && st.mainWeapon ? st.mainWeapon.type : '';
  if (wpType === 'bow') return 'bow';
  if (wpType === 'crossbow') return 'crossbow';
  var ud = unitDefByType(aiUnit.piece.unitType);
  var bt = ud ? (ud.baseType || ud.type) : 'infantry';
  if (bt === 'cavalry') return 'cavalry';
  if (bt === 'flying') return 'flying';
  if (bt === 'beast' || bt === 'beast_infantry') return 'beast';
  return 'infantry';
}

// 困难/传说：当前能打到人时，寻找更好的位置
// 弓兵：不贴脸 > 攻击 > 队友
// 弩兵：攻击 > 队友 > 不贴脸
// 骑兵/空军：找侧袭/背袭位 + 游走
// 步兵/野兽：队友 > 攻击 > 推进
function aiDecideMoveOptimize(aiUnit, enemies, allies, st) {
  var actualMove = st ? st.movement : 1;
  var maxSteps = actualMove;
  var candidates = aiGetMoveCandidates(aiUnit, maxSteps);
  if (candidates.length === 0) return null;

  // 步兵偷袭应对（仅困难/传说难度）：近战单位已在敌方步兵1格内，且移动+攻击范围内无可击杀目标时，不移动
  var myUd = unitDefByType(aiUnit.piece.unitType);
  var myBaseType = myUd ? (myUd.baseType || 'infantry') : 'infantry';
  var isRanged = isRangedWeapon(st);
  if (!isRanged && myBaseType !== 'flying' && AIState.difficulty !== 'easy') {
    if (aiIsAdjacentToInfantry(aiUnit.piece.hex, enemies)) {
      var killable = aiFindKillableInRange(aiUnit, enemies, st);
      if (!killable) {
        return null; // 不移动
      }
    }
  }

  var myRange = st ? (st.allowedRange || 1) : 1;
  var role = aiClassify(aiUnit, st);
  var strategy = AIState.config ? AIState.config.moveStyle : 'coordinated';

  // 候选格里加上当前位置（确保不会无意义移动）
  candidates.unshift({ hex: aiUnit.piece.hex, dist: 0 });

  var best = null, bestScore = -Infinity;
  candidates.forEach(function(c) {
    var canAttackAny = false, attackDist = Infinity, attackTarget = null;
    enemies.forEach(function(e) {
      if (e.piece._routed) return;
      var d = hDist(c.hex, e.piece.hex);
      if (d <= myRange) { canAttackAny = true; if (d < attackDist) { attackDist = d; attackTarget = e; } }
    });

    var surrounded = false;
    enemies.forEach(function(e) {
      if (e.piece._routed) return;
      if (hDist(c.hex, e.piece.hex) <= 1) surrounded = true;
    });

    var minAllyDist = Infinity;
    allies.forEach(function(a) {
      if (a.piece._routed || a === aiUnit) return;
      var d = hDist(c.hex, a.piece.hex);
      if (d < minAllyDist) minAllyDist = d;
    });

    // 方位计算（骑兵/空军用）
    var az = 'front';
    if (strategy !== 'toward' && attackTarget && attackTarget.piece._facing !== undefined && typeof getAttackAzimuth === 'function') {
      az = getAttackAzimuth(c.hex, attackTarget.piece.hex, attackTarget.piece._facing);
    }

    // 友军分（不贴脸时不重要，贴脸时有援军就好）
    var allyScore = 0;
    if (isFinite(minAllyDist)) {
      if (minAllyDist <= 1) allyScore = 400;
      else if (minAllyDist <= 2) allyScore = 280;
      else if (minAllyDist <= 3) allyScore = 160;
      else allyScore = -(minAllyDist - 3) * 40;
    }

    // 安全分（不被贴脸）
    var safeScore = !surrounded ? 800 : -800;

    // 攻击分（能打到人）
    var atkScore = canAttackAny ? 1200 : -600;
    if (canAttackAny) atkScore += Math.max(0, myRange - attackDist) * 15; // 距离越近越好

    // 传说集火
    var focusBonus = (strategy === 'legend' && attackTarget && AIState.assignedTargets[attackTarget.key] && AIState.assignedTargets[attackTarget.key].count >= 1) ? 500 : 0;

    // 通道评估：战术卡位加分，钻死胡同惩罚（仅地面单位）
    // 数值与 aiDecideMove 统一：战术卡位+350，死胡同-500，瓶颈-200
    var bnBonus = 0;
    if (role !== 'flying') {
      try {
        var bnEval = aiEvaluatePositionBottleneck(c.hex, st, aiUnit, enemies);
        if (bnEval.isTacticalChoke) {
          bnBonus = 350;
        } else if (bnEval.isDeadEnd) {
          bnBonus = -500;
        } else if (bnEval.isBottleneck) {
          bnBonus = -200;
        }
      } catch(e) {
        // 通道评估出错时忽略，不影响主流程
      }
    }

    var score = 0;

    if (role === 'bow') {
      // 弓兵：能攻击是最高优先级，其次是安全和队友
      // 修正：原来safeScore*1.2导致弓兵宁愿放弃攻击也要安全，现在攻击是最高优先级
      // safeScore=±800, atkScore=+1200/-600, allyScore≤400
      // 能攻击且安全=2000, 能攻击但贴脸=400, 打不到人=-600
      score = atkScore + safeScore + allyScore + focusBonus + bnBonus;
    } else if (role === 'crossbow') {
      // 弩兵：攻击 > 队友 > 安全（贴脸无所谓）
      score = atkScore * 1.5 + allyScore + safeScore * 0.3 + focusBonus + bnBonus;
    } else if (role === 'cavalry' || role === 'flying') {
      // 骑兵/空军：有攻击位是硬性条件，否则不移动
      if (!canAttackAny) return;
      // 有攻击位 > 侧袭/背袭 > 队友
      var flankScore = 0;
      if (az === 'rear') flankScore = 2000;
      else if (az === 'flank') flankScore = 1200;
      // 骑兵/空军切敌方远程兵加分（不限 flying，cavalry 也要）
      if (attackTarget) {
        var tUD = unitDefByType(attackTarget.piece.unitType);
        var tWpn = tUD && tUD.equipment && tUD.equipment.mainWeapon
          ? (ED && ED.weapons ? ED.weapons.find(function(w) { return w.id === tUD.equipment.mainWeapon; }) : null) : null;
        if (tWpn && (tWpn.type === 'bow' || tWpn.type === 'crossbow')) flankScore += 1000;
      }
      // Legend + focus_ranged 战术：额外加分
      if (strategy === 'legend' && AIState.commanderPlan && AIState.commanderPlan.tactic === 'focus_ranged') {
        flankScore += 500;
      }
      score = atkScore + flankScore + allyScore * 0.3 + focusBonus + bnBonus;
      // 空军孤立惩罚：友军距离>3时大幅扣分，防止孤军深入被集火秒杀
      if (role === 'flying' && isFinite(minAllyDist) && minAllyDist > 3) {
        score -= (minAllyDist - 3) * 300;
      }
    } else {
      // 步兵/野兽：队友 > 攻击 > 推进
      if (!canAttackAny) return;
      score = allyScore * 2 + atkScore + focusBonus + bnBonus;
      // Legend：步兵为远程让位（若友方远程被贴脸需撤退，让出通道加分）
      if (strategy === 'legend' && AIState.commanderPlan && AIState.commanderPlan.protectList.length > 0) {
        // 检查是否远离被保护的远程单位（让出通道）
        var protectBonus = 0;
        AIState.commanderPlan.protectList.forEach(function(pk) {
          var prot = BoardAPI.getPiece(pk); // 使用 BoardAPI 解耦
          if (!prot || prot._routed) return;
          var dToProt = hDist(c.hex, prot.hex);
          if (dToProt >= 2) protectBonus += 30; // 离被保护单位远=让位
        });
        score += protectBonus;
        // 同时检查是否阻挡了被保护单位的撤退路径（远离敌人方向）
        // 简化处理：步兵若站在被保护单位与敌人之间且距离<=1，扣分
        AIState.commanderPlan.protectList.forEach(function(pk) {
          var prot = BoardAPI.getPiece(pk); // 使用 BoardAPI 解耦
          if (!prot || prot._routed) return;
          enemies.forEach(function(e) {
            if (e.piece._routed) return;
            // 是否挡在 prot 和 enemy 之间
            var dProtEnemy = hDist(prot.hex, e.piece.hex);
            if (dProtEnemy <= 2) {
              var dSelfProt = hDist(c.hex, prot.hex);
              var dSelfEnemy = hDist(c.hex, e.piece.hex);
              if (dSelfProt <= 1 && dSelfEnemy <= 1) score -= 50; // 挡路了
            }
          });
        });
      }
    }

    if (score > bestScore) { bestScore = score; best = c; }
  });

  if (best && bestScore > 5 && hDist(best.hex, aiUnit.piece.hex) > 0) return best;
  return null;
}

// 主移动决策函数（当前打不到任何人时调用）
function aiDecideMove(aiUnit, target, allies, enemies) {
  var config = AIState.config;
  var strategy = config ? config.moveStyle : 'toward';
  var st = getPieceStats(aiUnit.piece);
  var maxSteps = st ? st.movement : 1;
  var candidates = aiGetMoveCandidates(aiUnit, maxSteps);
  if (candidates.length === 0) return null;

  // 步兵偷袭应对（仅困难/传说难度）：近战单位已在敌方步兵1格内，且移动+攻击范围内无可击杀目标时，不移动（避免触发偷袭）
  var myUd = unitDefByType(aiUnit.piece.unitType);
  var myBaseType = myUd ? (myUd.baseType || 'infantry') : 'infantry';
  var isRanged = isRangedWeapon(st);
  if (!isRanged && myBaseType !== 'flying' && AIState.difficulty !== 'easy') {
    // 近战非飞行单位：检查是否已在敌方步兵1格内
    if (aiIsAdjacentToInfantry(aiUnit.piece.hex, enemies)) {
      // 检查移动+攻击范围内是否有可击杀目标
      var killable = aiFindKillableInRange(aiUnit, enemies, st);
      if (!killable) {
        return null; // 不移动，原地交战
      }
    }
  }


  var myRange = st ? (st.allowedRange || 1) : 1;
  var role = aiClassify(aiUnit, st);

  if (strategy === 'toward') {
    // 简单：按 role 简化决策
    // 勇敢判断在循环外做一次（检查当前是否被近身）
    var isBraveCavToward = (role === 'cavalry' || role === 'flying') && aiShouldBeBrave(aiUnit, enemies);
    var bestS = null, bestScoreS = -Infinity;
    candidates.forEach(function(c) {
      var score = 0;
      var minEnemyDist = Infinity;
      enemies.forEach(function(e) {
        if (e.piece._routed) return;
        var d = hDist(c.hex, e.piece.hex);
        if (d < minEnemyDist) minEnemyDist = d;
        if (d <= myRange) score += 40;
      });

      if (role === 'bow') {
        // 弓兵：保持 3-4 格距离，被贴脸逃向远离方向
        var pinned = minEnemyDist <= 1;
        if (pinned) {
          // 被贴脸：远离敌人方向优先
          score += minEnemyDist * 50;
        } else {
          // 未被贴脸：理想距离 3-4 格
          if (minEnemyDist >= 3 && minEnemyDist <= 4) score += 60;
          else if (minEnemyDist < 2) score -= 80;
          else if (minEnemyDist > 5) score -= (minEnemyDist - 5) * 8;
          if (minEnemyDist <= myRange) score += 30; // 能打到加分
        }
      } else if (isBraveCavToward) {
        // 勇敢骑兵/飞兵（当前被近身且血量士气达标）：切后排
        var backlineDist = Infinity;
        enemies.forEach(function(e) {
          if (e.piece._routed) return;
          var ud = unitDefByType(e.piece.unitType);
          if (ud && ud.type === 'ranged') {
            var d = hDist(c.hex, e.piece.hex);
            if (d < backlineDist) backlineDist = d;
          }
        });
        if (backlineDist < Infinity) {
          score += (20 - backlineDist) * 30; // 越靠近后排分越高
        } else {
          score -= minEnemyDist * 5; // 没有后排可切，冲最近敌人
        }
      } else if (role === 'cavalry' || role === 'flying' || role === 'beast') {
        // 骑兵/空军/野兽：直接冲最近敌人
        score -= minEnemyDist * 5;
      } else {
        // 步兵/弩兵：朝目标移动
        score -= hDist(c.hex, target.piece.hex) * 3;
      }
      if (score > bestScoreS) { bestScoreS = score; bestS = c; }
    });
    return bestS;
  }

  // 困难/传说：按兵种职责，三个维度同时打分
  var best = null, bestScore = -Infinity;
  candidates.forEach(function(c) {
    var distToTarget = hDist(c.hex, target.piece.hex);

    var canAttackAny = false, nearestEnemyDist = Infinity;
    enemies.forEach(function(e) {
      if (e.piece._routed) return;
      var d = hDist(c.hex, e.piece.hex);
      if (d <= myRange) canAttackAny = true;
      if (d < nearestEnemyDist) nearestEnemyDist = d;
    });

    var surrounded = false;
    enemies.forEach(function(e) {
      if (e.piece._routed) return;
      if (hDist(c.hex, e.piece.hex) <= 1) surrounded = true;
    });

    var minAllyDist = Infinity;
    allies.forEach(function(a) {
      if (a.piece._routed || a === aiUnit) return;
      var d = hDist(c.hex, a.piece.hex);
      if (d < minAllyDist) minAllyDist = d;
    });

    var allyScore = 0;
    if (isFinite(minAllyDist)) {
      if (minAllyDist <= 1) allyScore = 400;
      else if (minAllyDist <= 2) allyScore = 280;
      else if (minAllyDist <= 3) allyScore = 160;
      else allyScore = -(minAllyDist - 3) * 40;
    }

    // 勇敢骑兵/飞兵判断（当前被近身 且 血量>50% 且 士气>30）
    var isBraveCav2 = (role === 'cavalry' || role === 'flying') && aiShouldBeBrave(aiUnit, enemies);

    // 后排距离（勇敢时切后排用，每个候选格子计算一次）
    var backlineDist = Infinity;
    if (isBraveCav2) {
      enemies.forEach(function(e) {
        if (e.piece._routed) return;
        var ud = unitDefByType(e.piece.unitType);
        if (ud && ud.type === 'ranged') {
          var d = hDist(c.hex, e.piece.hex);
          if (d < backlineDist) backlineDist = d;
        }
      });
    }

    // 安全分：被近身通常严重扣分，但勇敢骑兵/飞兵除外
    var safeScore;
    if (isBraveCav2 && surrounded) {
      safeScore = 200;
    } else {
      safeScore = !surrounded ? 800 : -800;
    }
    var atkScore = canAttackAny ? 1200 : -600;
    var focusBonus = (strategy === 'legend' && AIState.assignedTargets[target.key] && AIState.assignedTargets[target.key].count >= 1) ? 500 : 0;

    // 通道评估：区分"战术卡位"（鼓励）和"钻入死胡同"（惩罚），仅地面单位
    var bottleneckPenalty = 0;
    if (role !== 'flying' && !canAttackAny) {
      try {
        var bnEval = aiEvaluatePositionBottleneck(c.hex, st, aiUnit, enemies);
        if (bnEval.isTacticalChoke) {
          bottleneckPenalty = 350;
        } else if (bnEval.isDeadEnd) {
          bottleneckPenalty = -500;
          if (distToTarget > 3) bottleneckPenalty -= 300;
        } else if (bnEval.isBottleneck) {
          bottleneckPenalty = -200;
          if (distToTarget > 3) bottleneckPenalty -= 200;
        }
      } catch(e) {
        // 通道评估出错时忽略，不影响主流程
      }
    }

    // 方位（骑兵/空军用）
    var az = 'front';
    if (target.piece._facing !== undefined && typeof getAttackAzimuth === 'function') {
      az = getAttackAzimuth(c.hex, target.piece.hex, target.piece._facing);
    }

    var score = 0;

    if (role === 'bow') {
      // 弓兵：攻击 > 安全 > 队友（修复：原safeScore*1.2导致弓兵宁可不攻击也要安全）
      // 优先级：能攻击+安全 > 能攻击+贴脸 > 打不到+安全 > 打不到+贴脸
      score = atkScore + safeScore + allyScore - distToTarget * 8 + focusBonus + bottleneckPenalty;
    } else if (role === 'crossbow') {
      // 弩兵：攻击 > 队友 > 不贴脸
      score = atkScore * 1.5 + allyScore + safeScore * 0.3 - distToTarget * 6 + focusBonus + bottleneckPenalty;
    } else if (role === 'cavalry' || role === 'flying') {
      // 骑兵/空军：侧袭背袭 > 靠近 > 队友(次要)
      var flankScore = 0;
      if (az === 'rear') flankScore = 2000;
      else if (az === 'flank') flankScore = 1200;
      // 骑兵/空军切敌方远程兵加分（与 aiDecideMoveOptimize 统一）
      var tUD = unitDefByType(target.piece.unitType);
      var tWpn = tUD && tUD.equipment && tUD.equipment.mainWeapon
        ? (ED && ED.weapons ? ED.weapons.find(function(w) { return w.id === tUD.equipment.mainWeapon; }) : null) : null;
      if (tWpn && (tWpn.type === 'bow' || tWpn.type === 'crossbow')) flankScore += 1000;
      score = atkScore + flankScore + allyScore * 0.3 - distToTarget * 4 + focusBonus + bottleneckPenalty;
      // 勇敢骑兵/飞兵：切后排加分（越靠近敌方远程单位分越高）
      if (backlineDist < Infinity) {
        score += (20 - backlineDist) * 40;
      }
      // 空军孤立惩罚：友军距离>3时大幅扣分，防止孤军深入被集火秒杀
      if (role === 'flying' && isFinite(minAllyDist) && minAllyDist > 3) {
        score -= (minAllyDist - 3) * 300;
      }
    } else {
      // 步兵/野兽：队友 > 攻击 > 推进
      score = allyScore * 2 + atkScore - distToTarget * 6 + focusBonus + bottleneckPenalty;
    }

    if (score > bestScore) { bestScore = score; best = c; }
  });

  if (best) return best;
  return aiMoveToward(aiUnit, target);
}

// ===== 攻击决策 =====

function aiCanAttack(aiUnit, target, st) {
  var dist = hDist(aiUnit.piece.hex, target.piece.hex);
  var atkRange = st ? (st.allowedRange || 1) : 1;
  if (dist > atkRange) return false;
  // 弓兵惧怕近身：相邻有任一敌军→完全禁止攻击
  if (st && st.mainWeapon && st.mainWeapon.type === 'bow') {
    var bowBlocked = false;
    // 使用 BoardAPI 解耦 遍历棋子
    BoardAPI.forEach(function(p, k) {
      if (p.team !== aiUnit.piece.team && !p._routed && hDist(aiUnit.piece.hex, p.hex) <= 1) bowBlocked = true;
    });
    if (bowBlocked) return false;
  }
  return true;
}

function aiCalculateAggression(aiUnit, target, st) {
  var aggression = AIState.config ? AIState.config.aggression : 0.5;
  var dist = hDist(aiUnit.piece.hex, target.piece.hex);
  if (target.piece._currentHP && target.piece._initialHP) {
    var hpRatio = target.piece._currentHP / target.piece._initialHP;
    if (hpRatio < 0.3) aggression += 0.2;
    if (hpRatio > 0.8) aggression -= 0.1;
  }
  if (isRangedWeapon(st) && dist > 2) aggression += 0.1;
  if (st && st.mainWeapon && st.mainWeapon.type !== 'bow' && dist <= 1) aggression += 0.1;
  // 士气低于10才考虑撤退，且必须是仍有友军存活时才允许撤（孤军作战不退）
  var hasLivingAllies = false;
  var currentMorale = aiUnit.piece._currentMorale;
  // 使用 BoardAPI 解耦 遍历棋子
  BoardAPI.forEach(function(p, k) {
    if (p.team === aiUnit.piece.team && !p._routed && p !== aiUnit.piece) hasLivingAllies = true;
  });
  if (currentMorale !== undefined && currentMorale < 10 && hasLivingAllies) aggression = -1;
  return Math.max(0, Math.min(1, aggression));
}

function aiGetFlankingBonus(attacker, defender) {
  if (!AIState.config || !AIState.config.flankingBonus) return 0;
  var sideAllyCount = 0;
  for (var i = 0; i < AI_HEX_DIRS.length; i++) {
    var d = AI_HEX_DIRS[i];
    var nq = defender.piece.hex.q + d.q;
    var nr = defender.piece.hex.r + d.r;
    var ns = defender.piece.hex.s + d.s;
    var nkey = nq + ',' + nr + ',' + ns;
    var _np = BoardAPI.getPiece(nkey); // 使用 BoardAPI 解耦
    if (_np && _np.team === attacker.piece.team && !_np._routed) {
      sideAllyCount++;
    }
  }
  if (sideAllyCount >= 2) return 0.2;
  if (sideAllyCount >= 1) return 0.1;
  return 0;
}

// ===== 执行移动 =====
function aiExecuteMove(aiUnit, moveTarget) {
  if (!moveTarget) return false;
  // 追击检查：离开前看是否有敌方近战在附近
  if (typeof tryOpportunityAttack === 'function') {
    tryOpportunityAttack(aiUnit.key);
  }
  var oldKey = aiUnit.key;
  var newKey = moveTarget.hex.q + ',' + moveTarget.hex.r + ',' + moveTarget.hex.s;
  var oldHex = { q: aiUnit.piece.hex.q, r: aiUnit.piece.hex.r, s: aiUnit.piece.hex.s };
  var newHex = { q: moveTarget.hex.q, r: moveTarget.hex.r, s: moveTarget.hex.s };
  var movedDist = hDist(oldHex, newHex);
  BoardAPI.removePiece(oldKey); // 使用 BoardAPI 解耦
  aiUnit.piece.hex = newHex;
  aiUnit.piece._actionUsedThisTurn = true;
  aiUnit.piece._didActionThisTurn = true;
  aiUnit.piece._chargeDistance = movedDist;
  if (movedDist >= 1 && typeof getDirectionBetween === 'function') {
    aiUnit.piece._facing = getDirectionBetween(oldHex, newHex);
  }
  BoardAPI.addPiece(newKey, aiUnit.piece); // 使用 BoardAPI 解耦
  aiUnit.key = newKey;
  // ★ 启动移动动画：从 oldHex 插值到 newHex（260ms），修复敌方棋子瞬移问题
  // 动画系统通过 piece._animating 标记读取 _animFrom/_animTo，独立于 placedPieces 的键查找
  if (typeof startPieceMoveAnim === 'function') {
    startPieceMoveAnim(newKey, oldHex, newHex, 260, function() { if (typeof requestRender === 'function') requestRender(); });
  }
  if (typeof requestRender === 'function') requestRender();
  return true;
}

// ===== 执行攻击 =====
function aiExecuteAttack(aiUnit, target) {
  executeCombat(aiUnit.key, target.key);
  aiUnit.piece._facing = getDirectionBetween(aiUnit.piece.hex, target.piece.hex);
  return true;
}

// ===== AI 主回合循环 =====
function runAITurn(team) {
  // team 参数：指定哪一方是 AI 控制的（默认 'enemy'，斗蛐蛐模式下可能为 'player'）
  team = team || 'enemy';
  var enemyTeam = (team === 'enemy') ? 'player' : 'enemy';
  if (TurnState.currentPlayer !== team || TurnState.phase !== 'battle') return;

  // 如果是暂停恢复（_aiTurnActive 已经为 true），直接继续处理
  var isResuming = TurnState._aiTurnActive === true;
  if (isResuming) {
    _setAITurnGuard();
    setTimeout(function() { processNext(); }, battleDelay(250));
    return;
  }

  // 新回合：初始化AI状态
  var duelDifficulty = TurnState.difficulty;
  if (TurnState.isDuelBattle && window._duelBattleData) {
    var duelSideData = (team === 'enemy') ? window._duelBattleData.sideB : window._duelBattleData.sideA;
    if (duelSideData && duelSideData.intelligence) {
      duelDifficulty = duelSideData.intelligence;
    }
  }
  initAIState(duelDifficulty);
  TurnState._aiTurnActive = true;
  // 使用 BoardAPI 解耦 遍历棋子
  BoardAPI.forEach(function(p, key) {
    if (p.team === team && !p._routed) {
      p._actionUsedThisTurn = false;
      p._attackedThisTick = false;
      p._chargeDistance = 0;
    }
  });

  var enemyPieces = [];  // 注意：变量名沿用，实为 AI 己方棋子
  var playerPieces = [];  // 对方棋子（攻击目标）
  // 使用 BoardAPI 解耦 遍历棋子
  BoardAPI.forEach(function(p, key) {
    if (p._routed) return;
    if (p.team === team) {
      enemyPieces.push({ key: key, piece: p });
    } else {
      playerPieces.push({ key: key, piece: p });
    }
  });

  if (enemyPieces.length === 0 || playerPieces.length === 0) {
    setTimeout(function() { endTurn(); }, battleDelay(400));
    return;
  }

  // 计算AI阵型中心
  if (enemyPieces.length > 0) {
    var sumQ = 0, sumR = 0;
    enemyPieces.forEach(function(e) {
      sumQ += e.piece.hex.q;
      sumR += e.piece.hex.r;
    });
    AIState.formationCenter = (function() {
      var fcQ = Math.round(sumQ / enemyPieces.length);
      var fcR = Math.round(sumR / enemyPieces.length);
      return { q: fcQ, r: fcR, s: -(fcQ + fcR) };
    })();
  }

  // 传说难度：开局选定集火目标
  if (AIState.difficulty === 'legend' && playerPieces.length > 0) {
    var weakest = null, weakestHP = Infinity;
    playerPieces.forEach(function(p) {
      if (p.piece._routed) return;
      var ratio = p.piece._currentHP / Math.max(1, p.piece._initialHP);
      if (ratio < weakestHP) { weakestHP = ratio; weakest = p; }
    });
    if (weakest) AIState.focusedTargetKey = weakest.key;
  }

  // ===== 指挥官统筹层：评估全局战术 + 生成动态行动顺序 =====
  var commanderPlan = aiCommanderPlan(enemyPieces, playerPieces);
  AIState.commanderPlan = commanderPlan;  // 供 processUnitWithAnim 中的单位决策参考
  if (commanderPlan.focusTargetKey) {
    AIState.focusedTargetKey = commanderPlan.focusTargetKey;  // 兼容原有集火逻辑
  }
  var actionQueue = commanderPlan.actionOrder;
  AIState.actionQueue = actionQueue;
  AIState.actionIdx = 0;

  AIState.actedThisTurn.clear();
  AIState.assignedTargets = {};

  // ===== AI 回合安全守护 =====
  var _aiTurnGuard = null;
  function _clearAITurnGuard() {
    if (_aiTurnGuard) { clearTimeout(_aiTurnGuard); _aiTurnGuard = null; }
  }
  function _setAITurnGuard() {
    _clearAITurnGuard();
    _aiTurnGuard = setTimeout(function() {
      // 10秒仍未结束，强制收尾
      if (TurnState.phase === 'battle' && TurnState.currentPlayer === team) {
        AIState.assignedTargets = {};
        requestRender();
        endTurn();
      }
    }, 10000);
  }

  var actionIdx = AIState.actionIdx || 0;

  function getLiveEnemies() {
    var list = [];
    // 使用 BoardAPI 解耦 遍历棋子
    BoardAPI.forEach(function(p, key) {
      if (!p._routed && p.team === enemyTeam) {
        list.push({ key: key, piece: p });
      }
    });
    return list;
  }

  function processUnitWithAnim(unit, enemies, callback) {
    if (unit.piece._routed) { callback(); return; }
    var st = getPieceStats(unit.piece);
    if (!st) {
      if (console && console.warn) console.warn('[AI] 无法获取单位属性', unit.piece.unitType);
      callback();
      return;
    }

    if (AIState.config.skipChance > 0 && Math.random() < AIState.config.skipChance) {
      unit.piece._actionUsedThisTurn = true;
      AIState.actedThisTurn.add(unit.key);
      if (typeof requestRender === 'function') requestRender();
      callback();
      return;
    }

    // 感知指挥官战术
    var plan = AIState.commanderPlan;
    var tacticFocusRanged = plan && plan.tactic === 'focus_ranged';
    var role = aiClassify(unit, st);

    var isRanged = isRangedWeapon(st);
    var myRange = st.allowedRange || 1;
    var strategy = AIState.config.moveStyle || 'toward';

    // 第1步：从当前能攻击到的目标中选最优
    var reachableTargets = [];
    enemies.forEach(function(e) {
      if (e.piece._routed) return;
      if (aiCanAttack(unit, e, st)) reachableTargets.push(e);
    });

    if (reachableTargets.length > 0) {
      // 士气<10撤退（但有可击杀目标时跳过撤退，优先击杀）
      var hasAlliesCheck = false;
      var curMorale = unit.piece._currentMorale;
      // 使用 BoardAPI 解耦 遍历棋子
      BoardAPI.forEach(function(p, k) {
        if (p.team === unit.piece.team && !p._routed && p !== unit.piece) hasAlliesCheck = true;
      });
      // 检查是否有可击杀目标，有则跳过撤退
      var killableTarget = aiFindKillableTarget(unit, reachableTargets, st);
      if (curMorale !== undefined && curMorale < 10 && hasAlliesCheck && !killableTarget) {
        var retreatTarget = aiFindRetreat(unit, enemies, enemyPieces);
        if (retreatTarget) aiExecuteMove(unit, retreatTarget);
        AIState.actedThisTurn.add(unit.key);
        requestRender();
        setTimeout(function() { callback(); }, battleDelay(350));
        return;
      }

      // 选目标
      var immediateTarget;
      switch (AIState.config.targeting) {
        case 'tactical': immediateTarget = aiTargetTactical(unit, reachableTargets); break;
        case 'smart': immediateTarget = aiTargetSmart(unit, reachableTargets); break;
        default: immediateTarget = aiTargetNearest(unit, reachableTargets); break;
      }
      if (!immediateTarget) immediateTarget = reachableTargets[0];
      var isFocusTarget = plan && plan.focusTargetKey && immediateTarget && immediateTarget.key === plan.focusTargetKey;

      if (AIState.config.coordinatedAttack) {
        AIState.assignedTargets[immediateTarget.key] = AIState.assignedTargets[immediateTarget.key] || { count: 0 };
        AIState.assignedTargets[immediateTarget.key].count++;
      }

      // 简单难度：能打到就不动，直接攻击
      if (strategy === 'toward') {
        aiExecuteAttack(unit, immediateTarget);
        unit.piece._actionUsedThisTurn = true;
        unit.piece._attackedThisTick = true;
        AIState.actedThisTurn.add(unit.key);
        checkAndTriggerVictory();
        requestRender();
        setTimeout(function() { callback(); }, battleDelay(350));
        return;
      }

      // 困难/传说：检查是否有更好的位置（靠近友军+能攻击）
      var betterPos = aiDecideMoveOptimize(unit, enemies, enemyPieces, st);
      if (betterPos && hDist(betterPos.hex, unit.piece.hex) > 0) {
        aiExecuteMove(unit, betterPos);
        unit.piece._actionUsedThisTurn = true;
        setTimeout(function() {
          var postEnemies = getLiveEnemies();
          var reachable = [];
          for (var pi = 0; pi < postEnemies.length; pi++) {
            if (aiCanAttack(unit, postEnemies[pi], st)) reachable.push(postEnemies[pi]);
          }
          if (reachable.length > 0) {
            var bestTarget = aiSelectTarget(unit, reachable);
            if (!bestTarget) bestTarget = reachable[0];
            aiExecuteAttack(unit, bestTarget);
            unit.piece._attackedThisTick = true;
          } else if (immediateTarget && !immediateTarget.piece._routed && aiCanAttack(unit, immediateTarget, st)) {
            aiExecuteAttack(unit, immediateTarget);
            unit.piece._attackedThisTick = true;
          }
          AIState.actedThisTurn.add(unit.key);
          requestRender();
          checkAndTriggerVictory();
          setTimeout(function() { callback(); }, battleDelay(350));
        }, battleDelay(350));
        return;
      }

      // 没有更好的位置→原地攻击
      aiExecuteAttack(unit, immediateTarget);
      unit.piece._actionUsedThisTurn = true;
      unit.piece._attackedThisTick = true;
      AIState.actedThisTurn.add(unit.key);
      checkAndTriggerVictory();
      requestRender();
      setTimeout(function() { callback(); }, battleDelay(350));
      return;
    }

    // 第2步：当前打不到任何人，选最优目标移动
    var target = aiSelectTarget(unit, enemies);
    if (!target) { callback(); return; }

    if (AIState.config.coordinatedAttack) {
      AIState.assignedTargets[target.key] = AIState.assignedTargets[target.key] || { count: 0 };
      AIState.assignedTargets[target.key].count++;
    }

    var moveTarget = aiDecideMove(unit, target, enemyPieces, enemies);
    if (moveTarget && hDist(moveTarget.hex, unit.piece.hex) > 0) {
      aiExecuteMove(unit, moveTarget);
      unit.piece._actionUsedThisTurn = true;
      setTimeout(function() {
        var postEnemies = getLiveEnemies();
        var reachable2 = [];
        for (var pj = 0; pj < postEnemies.length; pj++) {
          if (aiCanAttack(unit, postEnemies[pj], st)) reachable2.push(postEnemies[pj]);
        }
        if (reachable2.length > 0) {
          var bestTarget2 = aiSelectTarget(unit, reachable2);
          if (!bestTarget2) bestTarget2 = reachable2[0];
          aiExecuteAttack(unit, bestTarget2);
          unit.piece._attackedThisTick = true;
          checkAndTriggerVictory();
        }
        AIState.actedThisTurn.add(unit.key);
        requestRender();
        setTimeout(function() { callback(); }, battleDelay(350));
      }, battleDelay(350));
      return;
    }

    // 无法移动也无法攻击→标记已行动（变暗但不打勾，因为未攻击）
    unit.piece._actionUsedThisTurn = true;
    AIState.actedThisTurn.add(unit.key);
    requestRender();
    callback();
  }

  function processNext() {
    if (TurnState.phase !== 'battle') { _clearAITurnGuard(); return; }
    // 观战暂停：停止处理下一个单位
    if (typeof _spectatorPaused !== 'undefined' && _spectatorPaused) {
      _clearAITurnGuard();
      return;
    }
    var livePlayer = getLiveEnemies();
    if (livePlayer.length === 0) {
      _clearAITurnGuard();
      requestRender();
      setTimeout(function() { endTurn(); }, battleDelay(400));
      return;
    }

    if (actionIdx >= AIState.actionQueue.length) {
      _clearAITurnGuard();
      TurnState._aiTurnActive = false;
      AIState.assignedTargets = {};
      requestRender();
      setTimeout(function() { endTurn(); }, battleDelay(500));
      return;
    }

    var unit = AIState.actionQueue[actionIdx];
    actionIdx++;
    AIState.actionIdx = actionIdx;

    var enemies = getLiveEnemies();
    try {
      processUnitWithAnim(unit, enemies, function() {
        requestRender();
        setTimeout(function() {
          processNext();
        }, battleDelay(250));
      });
    } catch(e) {
      console.error('AI processUnit error:', e, unit);
      requestRender();
      setTimeout(function() { processNext(); }, battleDelay(250));
    }
  }

  // 启动安全守护并开始行动
  _setAITurnGuard();
  setTimeout(function() { processNext(); }, battleDelay(400));
}

// ===== 调试 =====
function getAIDebugInfo() {
  return {
    difficulty: AIState.difficulty,
    config: AIState.config,
    assignedTargets: Object.keys(AIState.assignedTargets).length,
    actedCount: AIState.actedThisTurn.size,
    formationCenter: AIState.formationCenter,
    focusedTargetKey: AIState.focusedTargetKey
  };
}

// ===== 暴露到全局 =====
window.AIState = AIState;
window.getAIConfig = getAIConfig;
window.initAIState = initAIState;
window.getAIDebugInfo = getAIDebugInfo;
window.runAITurn = runAITurn;
window.DIFF_MAP = DIFF_MAP;
